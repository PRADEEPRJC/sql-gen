import spacy
import json

# Load the small English model from spaCy
# You may need to run 'python -m spacy download en_core_web_sm' once to download it.
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    print("Downloading spaCy model 'en_core_web_sm'...")
    from spacy.cli import download
    download("en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")

def filter_metadata_with_spacy(user_query, direct_fields, derived_fields, join_condition):
    """
    Analyzes a user query and filters the provided metadata to only include
    the most relevant fields and transformations.

    Args:
        user_query (str): The natural language query from the user.
        direct_fields (list): List of dictionaries for direct fields.
        derived_fields (list): List of dictionaries for derived fields.
        join_condition (str): The SQL join condition.

    Returns:
        dict: A dictionary containing the filtered metadata.
    """
    # Create a spaCy Doc object from the user query
    doc = nlp(user_query.lower())

    # Dictionaries to store the filtered metadata
    filtered_direct_fields = []
    filtered_derived_fields = []

    # Filter direct fields by checking for keyword matches in the user query
    for field in direct_fields:
        source_column = field['Source Column'].lower()
        alias_name = field['Alias Name'].lower()
        
        # Check if the source column or alias is present in the query's tokens
        if any(token.text in source_column or token.lemma_ in alias_name for token in doc):
            filtered_direct_fields.append(field)
            
    # Filter derived fields by checking for keyword matches in the user query
    for field in derived_fields:
        source_columns = field['Source Columns'].lower()
        transformation_logic = field['Transformation Logic'].lower()
        
        # Check if any of the source columns or transformation keywords are present
        if any(token.text in source_columns or token.lemma_ in transformation_logic for token in doc):
            filtered_derived_fields.append(field)

    # Return the reduced metadata
    return {
        'filtered_direct_fields': filtered_direct_fields,
        'filtered_derived_fields': filtered_derived_fields,
        'join_condition': join_condition
    }


# --- Example Usage ---

# 1. Define the metadata based on your provided information
DIRECT_FIELDS = [
    {"Source Table": "table1", "Source Column": "column1", "Alias Name": "column 1"},
    {"Source Table": "table1", "Source Column": "policy_status", "Alias Name": "Policy Status"},
    {"Source Table": "table1", "Source Column": "customer_id", "Alias Name": "Customer ID"},
    {"Source Table": "table2", "Source Column": "region", "Alias Name": "region"}
]

DERIVED_FIELDS = [
    {"Source Table": "table1", "Source Columns": "column1,column2,column3", "Transformation Logic": "iff(column1==1,column2,column3)"},
    {"Source Table": "table1", "Source Columns": "policy_status", "Transformation Logic": "COUNT(CASE WHEN policy_status = 'new' THEN 1 END) AS new_policies"},
    {"Source Table": "table1", "Source Columns": "policy_status", "Transformation Logic": "COUNT(CASE WHEN policy_status = 'renewal' THEN 1 END) AS renewal_policies"}
]

JOIN_CONDITION = "table1 JOIN table2 ON table1.id = table2.id"

# 2. Define a user query
user_query = "what is the policy count for new and renewal policies?"

# 3. Filter the metadata using the function
filtered_metadata = filter_metadata_with_spacy(user_query, DIRECT_FIELDS, DERIVED_FIELDS, JOIN_CONDITION)

# 4. Print the result
print("Original User Query:")
print(f"'{user_query}'\n")

print("Filtered Metadata (ready for LLM prompt):")
# Use json.dumps to pretty-print the dictionary for readability
print(json.dumps(filtered_metadata, indent=2))
