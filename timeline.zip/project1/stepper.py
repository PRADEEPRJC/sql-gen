import dash_mantine_components as dmc
from dash_iconify import DashIconify

def get_icon(icon, size=20):
    return DashIconify(icon=icon, height=size)

def create_stepper_steps(progress):
    """Build stepper UI from progress dict"""

    steps_config = [
        {
            "key": "sql",
            "label": "SQL Query Generated",
            "description": "Generating SQL query...",
            "icon": "material-symbols:code",
            "progress_icon": "material-symbols:code",
            "completed_icon": "material-symbols:code-blocks",
            "link": "/sql"
        },
        {
            "key": "data",
            "label": "SQL Executed",
            "description": "Executing SQL query...",
            "icon": "material-symbols:database",
            "progress_icon": "material-symbols:database",
            "completed_icon": "material-symbols:database-export",
            "link": "/data"
        },
        {
            "key": "dashboard",
            "label": "Dashboard Created",
            "description": "Creating dashboard...",
            "icon": "material-symbols:dashboard",
            "progress_icon": "material-symbols:dashboard",
            "completed_icon": "material-symbols:dashboard-customize",
            "link": "/dashboard"
        },
    ]

    steps = []
    for step_config in steps_config:
        step_status = progress.get("steps", {}).get(step_config["key"], {"status": "pending"})
        status = step_status.get("status")
        retry = step_status.get("retry", 0)

        # Content message
        if status == "completed":
            content = dmc.Alert(
                dmc.Anchor("Step completed successfully! View details", href=step_config["link"]),
                color="green",
                variant="light"
            )
        elif status == "in_progress":
            content = dmc.Alert("Step in progress...", color="blue", variant="light")
        elif status == "failed":
            content = dmc.Alert(
                f"Step failed. Retries: {retry}",
                color="red",
                variant="light"
            )
        else:
            content = dmc.Text("Waiting to start...", c="dimmed", size="sm")

        step = dmc.StepperStep(
            label=step_config["label"],
            description=step_config["description"],
            icon=get_icon(step_config["icon"]),
            progressIcon=get_icon(step_config["progress_icon"]),
            completedIcon=get_icon(step_config["completed_icon"]),
            loading=status == "in_progress",
            children=[content]
        )
        steps.append(step)

    # Completion step
    if all(step.get("status") == "completed" for step in progress.get("steps", {}).values()):
        steps.append(
            dmc.StepperCompleted(
                children=[
                    dmc.Alert(
                        [
                            dmc.Text("🎉 All steps completed successfully!", size="lg", fw=500),
                            dmc.Text("Your dashboard is ready!", size="sm", mt=5)
                        ],
                        color="green",
                        variant="filled"
                    )
                ]
            )
        )

    return steps
