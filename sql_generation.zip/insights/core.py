import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, html, dcc, dash_table
import dash_bootstrap_components as dbc
from datetime import datetime, timedelta
import re

class AutomatedInsightsGenerator:
    """Generate insights from DataFrame without LLM"""
    
    def __init__(self, df: pd.DataFrame, user_question: str):
        self.df = df
        self.user_question = user_question.lower()
        self.numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        self.categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        self.datetime_cols = df.select_dtypes(include=['datetime64']).columns.tolist()
        
        # Identify key column types based on common insurance patterns
        self.column_mapping = self._identify_column_types()
    
    def _identify_column_types(self) -> Dict[str, List[str]]:
        """Identify column purposes using pattern matching"""
        mapping = {
            'premium': [],
            'loss': [],
            'policy': [],
            'customer': [],
            'date': [],
            'geographic': [],
            'product': [],
            'channel': []
        }
        
        patterns = {
            'premium': r'premium|written|earned|revenue',
            'loss': r'loss|claim|paid|incurred|severity',
            'policy': r'policy|count|number|volume|new|renewal',
            'customer': r'customer|client|insured|age|gender',
            'date': r'date|time|period|month|year|quarter',
            'geographic': r'state|territory|region|zip|county|city',
            'product': r'product|line|coverage|type',
            'channel': r'channel|agent|broker|direct|online'
        }
        
        for col in self.df.columns:
            col_lower = col.lower()
            for category, pattern in patterns.items():
                if re.search(pattern, col_lower):
                    mapping[category].append(col)
                    break
        
        return mapping
    
    def generate_insights(self) -> Dict[str, Any]:
        """Generate comprehensive insights based on data patterns"""
        insights = {}
        
        # 1. Data Overview Insights
        insights['overview'] = self._generate_overview_insights()
        
        # 2. Relationship Insights (based on user question)
        insights['relationships'] = self._generate_relationship_insights()
        
        # 3. Trend Insights
        insights['trends'] = self._generate_trend_insights()
        
        # 4. Distribution Insights
        insights['distributions'] = self._generate_distribution_insights()
        
        # 5. Anomaly Insights
        insights['anomalies'] = self._generate_anomaly_insights()
        
        # 6. Business Rule Insights
        insights['business_rules'] = self._generate_business_insights()
        
        return insights
    
    def _generate_overview_insights(self) -> List[Dict]:
        """Generate high-level data overview insights"""
        insights = []
        
        # Data size and completeness
        total_rows = len(self.df)
        total_cols = len(self.df.columns)
        missing_data = self.df.isnull().sum().sum()
        completeness = ((total_rows * total_cols - missing_data) / (total_rows * total_cols)) * 100
        
        insights.append({
            'type': 'metric',
            'title': 'Data Completeness',
            'value': f"{completeness:.1f}%",
            'description': f"Dataset contains {total_rows:,} records with {total_cols} columns"
        })
        
        # Key metrics summary
        if self.numeric_cols:
            for col in self.numeric_cols[:3]:  # Top 3 numeric columns
                total_value = self.df[col].sum()
                avg_value = self.df[col].mean()
                insights.append({
                    'type': 'metric',
                    'title': f"Total {col.replace('_', ' ').title()}",
                    'value': self._format_number(total_value),
                    'description': f"Average: {self._format_number(avg_value)}"
                })
        
        return insights
    
    def _generate_relationship_insights(self) -> List[Dict]:
        """Generate insights about relationships between variables"""
        insights = []
        
        # Detect question intent
        if any(word in self.user_question for word in ['relation', 'relationship', 'compare', 'vs']):
            # Find numeric columns for correlation
            if len(self.numeric_cols) >= 2:
                corr_matrix = self.df[self.numeric_cols].corr()
                
                # Find strongest correlations
                correlations = []
                for i in range(len(corr_matrix.columns)):
                    for j in range(i+1, len(corr_matrix.columns)):
                        corr_val = corr_matrix.iloc[i, j]
                        if not np.isnan(corr_val):
                            correlations.append({
                                'var1': corr_matrix.columns[i],
                                'var2': corr_matrix.columns[j],
                                'correlation': abs(corr_val),
                                'direction': 'positive' if corr_val > 0 else 'negative'
                            })
                
                # Sort by correlation strength
                correlations.sort(key=lambda x: x['correlation'], reverse=True)
                
                for corr in correlations[:3]:  # Top 3 correlations
                    strength = 'strong' if corr['correlation'] > 0.7 else 'moderate' if corr['correlation'] > 0.4 else 'weak'
                    insights.append({
                        'type': 'relationship',
                        'title': f"{corr['var1']} vs {corr['var2']}",
                        'value': f"{strength.title()} {corr['direction']} correlation",
                        'description': f"Correlation coefficient: {corr['correlation']:.3f}",
                        'chart_data': {
                            'x': corr['var1'],
                            'y': corr['var2'],
                            'type': 'scatter'
                        }
                    })
        
        return insights
    
    def _generate_trend_insights(self) -> List[Dict]:
        """Generate trend-based insights"""
        insights = []
        
        # Time-based trends
        date_cols = self.datetime_cols + [col for col in self.df.columns if any(word in col.lower() for word in ['date', 'time', 'period'])]
        
        if date_cols and self.numeric_cols:
            date_col = date_cols[0]
            
            for numeric_col in self.numeric_cols[:2]:  # Top 2 numeric columns
                try:
                    # Convert to datetime if needed
                    df_copy = self.df.copy()
                    df_copy[date_col] = pd.to_datetime(df_copy[date_col])
                    df_sorted = df_copy.sort_values(date_col)
                    
                    # Calculate trend
                    x_vals = range(len(df_sorted))
                    y_vals = df_sorted[numeric_col].fillna(0)
                    
                    if len(y_vals) > 1:
                        trend_coef = np.polyfit(x_vals, y_vals, 1)[0]
                        
                        # Calculate percentage change
                        first_val = y_vals.iloc[0] if y_vals.iloc[0] != 0 else 1
                        last_val = y_vals.iloc[-1]
                        pct_change = ((last_val - first_val) / first_val) * 100
                        
                        direction = 'increasing' if trend_coef > 0 else 'decreasing'
                        insights.append({
                            'type': 'trend',
                            'title': f"{numeric_col.replace('_', ' ').title()} Trend",
                            'value': f"{abs(pct_change):.1f}% {direction}",
                            'description': f"Overall trend coefficient: {trend_coef:.2e}",
                            'chart_data': {
                                'x': date_col,
                                'y': numeric_col,
                                'type': 'line'
                            }
                        })
                except:
                    continue
        
        return insights
    
    def _generate_distribution_insights(self) -> List[Dict]:
        """Generate distribution-based insights"""
        insights = []
        
        # Categorical distributions
        for col in self.categorical_cols[:2]:  # Top 2 categorical columns
            value_counts = self.df[col].value_counts()
            
            if len(value_counts) > 1:
                top_category = value_counts.index[0]
                top_percentage = (value_counts.iloc[0] / len(self.df)) * 100
                
                insights.append({
                    'type': 'distribution',
                    'title': f"{col.replace('_', ' ').title()} Distribution",
                    'value': f"{top_category} dominates ({top_percentage:.1f}%)",
                    'description': f"Most frequent category out of {len(value_counts)} unique values",
                    'chart_data': {
                        'values': value_counts.values.tolist(),
                        'names': value_counts.index.tolist(),
                        'type': 'pie'
                    }
                })
        
        # Numeric distributions
        for col in self.numeric_cols[:2]:
            data = self.df[col].dropna()
            if len(data) > 0:
                skewness = data.skew()
                skew_desc = 'right-skewed' if skewness > 1 else 'left-skewed' if skewness < -1 else 'normally distributed'
                
                insights.append({
                    'type': 'distribution',
                    'title': f"{col.replace('_', ' ').title()} Distribution",
                    'value': f"Data is {skew_desc}",
                    'description': f"Skewness: {skewness:.2f}, Range: {data.min():.0f} to {data.max():.0f}",
                    'chart_data': {
                        'x': col,
                        'type': 'histogram'
                    }
                })
        
        return insights
    
    def _generate_anomaly_insights(self) -> List[Dict]:
        """Generate anomaly detection insights"""
        insights = []
        
        for col in self.numeric_cols[:2]:
            data = self.df[col].dropna()
            if len(data) > 0:
                # IQR method for outliers
                Q1 = data.quantile(0.25)
                Q3 = data.quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outliers = data[(data < lower_bound) | (data > upper_bound)]
                outlier_percentage = (len(outliers) / len(data)) * 100
                
                if outlier_percentage > 0:
                    insights.append({
                        'type': 'anomaly',
                        'title': f"{col.replace('_', ' ').title()} Outliers",
                        'value': f"{len(outliers)} outliers found ({outlier_percentage:.1f}%)",
                        'description': f"Values outside range [{lower_bound:.0f}, {upper_bound:.0f}]",
                        'severity': 'high' if outlier_percentage > 10 else 'medium' if outlier_percentage > 5 else 'low'
                    })
        
        return insights
    
    def _generate_business_insights(self) -> List[Dict]:
        """Generate insurance-specific business insights"""
        insights = []
        
        # Premium vs Loss insights
        premium_cols = [col for col in self.df.columns if 'premium' in col.lower()]
        loss_cols = [col for col in self.df.columns if any(x in col.lower() for x in ['loss', 'claim'])]
        
        if premium_cols and loss_cols:
            premium_col = premium_cols[0]
            loss_col = loss_cols[0]
            
            # Calculate loss ratio
            valid_data = self.df[(self.df[premium_col] > 0) & (self.df[loss_col] >= 0)]
            if len(valid_data) > 0:
                loss_ratios = valid_data[loss_col] / valid_data[premium_col]
                avg_loss_ratio = loss_ratios.mean()
                
                performance = 'profitable' if avg_loss_ratio < 0.7 else 'break-even' if avg_loss_ratio < 1.0 else 'unprofitable'
                insights.append({
                    'type': 'business',
                    'title': 'Loss Ratio Analysis',
                    'value': f"Portfolio is {performance}",
                    'description': f"Average loss ratio: {avg_loss_ratio:.2f}",
                    'chart_data': {
                        'x': premium_col,
                        'y': loss_col,
                        'type': 'scatter'
                    }
                })
        
        # Policy volume insights
        policy_cols = [col for col in self.df.columns if 'policy' in col.lower() or 'count' in col.lower()]
        if policy_cols:
            policy_col = policy_cols[0]
            total_policies = self.df[policy_col].sum()
            
            insights.append({
                'type': 'business',
                'title': 'Policy Portfolio Size',
                'value': f"{total_policies:,.0f} policies",
                'description': f"Total policy volume in dataset"
            })
        
        return insights
    
    def _format_number(self, value: float) -> str:
        """Format numbers for display"""
        if pd.isna(value):
            return "N/A"
        elif abs(value) >= 1e9:
            return f"${value/1e9:.1f}B"
        elif abs(value) >= 1e6:
            return f"${value/1e6:.1f}M"
        elif abs(value) >= 1e3:
            return f"${value/1e3:.0f}K"
        else:
            return f"${value:,.0f}"

class InsightsDashboard:
    """Create Dash dashboard to display insights"""
    
    def __init__(self, df: pd.DataFrame, insights: Dict[str, Any]):
        self.df = df
        self.insights = insights
    
    def create_dashboard(self) -> Dash:
        """Create the main dashboard"""
        app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
        
        app.layout = dbc.Container([
            self._create_header(),
            self._create_insights_section(),
            self._create_charts_section()
        ], fluid=True)
        
        return app
    
    def _create_header(self):
        """Create dashboard header"""
        return dbc.Row([
            dbc.Col([
                html.H2("📊 Automated Data Insights", className="text-center mb-4"),
                html.Hr()
            ])
        ])
    
    def _create_insights_section(self):
        """Create insights cards section"""
        all_insights = []
        
        # Collect all insights
        for category, insights_list in self.insights.items():
            all_insights.extend(insights_list)
        
        # Group insights by type for better organization
        insight_cards = []
        
        # Metrics row
        metric_insights = [i for i in all_insights if i.get('type') == 'metric']
        if metric_insights:
            metric_cards = [self._create_insight_card(insight, 'primary') for insight in metric_insights[:4]]
            insight_cards.append(
                dbc.Row([
                    dbc.Col(card, width=3) for card in metric_cards
                ], className="mb-4")
            )
        
        # Key findings
        key_findings = [i for i in all_insights if i.get('type') in ['relationship', 'trend', 'business']]
        if key_findings:
            finding_cards = []
            for insight in key_findings[:6]:  # Max 6 key findings
                card_color = self._get_insight_color(insight.get('type'))
                finding_cards.append(
                    dbc.Col([
                        self._create_detailed_insight_card(insight, card_color)
                    ], width=6, className="mb-3")
                )
            
            # Arrange in rows of 2
            for i in range(0, len(finding_cards), 2):
                row_cards = finding_cards[i:i+2]
                insight_cards.append(dbc.Row(row_cards))
        
        # Warnings/Anomalies
        anomaly_insights = [i for i in all_insights if i.get('type') == 'anomaly']
        if anomaly_insights:
            anomaly_cards = []
            for insight in anomaly_insights:
                severity = insight.get('severity', 'low')
                color = 'danger' if severity == 'high' else 'warning' if severity == 'medium' else 'info'
                anomaly_cards.append(
                    dbc.Col([
                        self._create_alert_card(insight, color)
                    ], width=4, className="mb-3")
                )
            
            if anomaly_cards:
                insight_cards.append(
                    dbc.Row([
                        dbc.Col([
                            html.H4("⚠️ Anomalies Detected", className="mb-3")
                        ], width=12)
                    ])
                )
                insight_cards.append(dbc.Row(anomaly_cards))
        
        return html.Div(insight_cards)
    
    def _create_charts_section(self):
        """Create charts section based on insights"""
        charts = []
        
        # Find insights with chart data
        chart_insights = []
        for category, insights_list in self.insights.items():
            for insight in insights_list:
                if 'chart_data' in insight:
                    chart_insights.append(insight)
        
        if chart_insights:
            charts.append(
                dbc.Row([
                    dbc.Col([
                        html.H4("📈 Visual Analysis", className="mb-3")
                    ], width=12)
                ])
            )
            
            # Create charts
            chart_components = []
            for i, insight in enumerate(chart_insights[:4]):  # Max 4 charts
                fig = self._create_chart_from_insight(insight)
                chart_components.append(
                    dbc.Col([
                        dcc.Graph(figure=fig)
                    ], width=6, className="mb-4")
                )
            
            # Arrange charts in rows of 2
            for i in range(0, len(chart_components), 2):
                row_charts = chart_components[i:i+2]
                charts.append(dbc.Row(row_charts))
        
        return html.Div(charts)
    
    def _create_insight_card(self, insight: Dict, color: str):
        """Create simple metric card"""
        return dbc.Card([
            dbc.CardBody([
                html.H6(insight['title'], className="card-subtitle mb-2 text-muted"),
                html.H4(insight['value'], className="card-title text-primary"),
                html.P(insight['description'], className="card-text small")
            ])
        ], color=color, outline=True, className="h-100 text-center")
    
    def _create_detailed_insight_card(self, insight: Dict, color: str):
        """Create detailed insight card"""
        return dbc.Card([
            dbc.CardHeader([
                html.H6(insight['title'], className="mb-0")
            ]),
            dbc.CardBody([
                html.H5(insight['value'], className=f"text-{color}"),
                html.P(insight['description'], className="mb-0")
            ])
        ], outline=True, className="h-100")
    
    def _create_alert_card(self, insight: Dict, color: str):
        """Create alert-style card for anomalies"""
        return dbc.Alert([
            html.H6(insight['title'], className="alert-heading"),
            html.P(insight['value']),
            html.Hr(),
            html.P(insight['description'], className="mb-0 small")
        ], color=color, className="mb-0")
    
    def _create_chart_from_insight(self, insight: Dict):
        """Create chart based on insight data"""
        chart_data = insight['chart_data']
        chart_type = chart_data.get('type', 'scatter')
        
        try:
            if chart_type == 'scatter':
                fig = px.scatter(self.df, x=chart_data['x'], y=chart_data['y'], 
                               title=insight['title'])
            elif chart_type == 'line':
                fig = px.line(self.df, x=chart_data['x'], y=chart_data['y'],
                             title=insight['title'])
            elif chart_type == 'histogram':
                fig = px.histogram(self.df, x=chart_data['x'], title=insight['title'])
            elif chart_type == 'pie':
                fig = go.Figure(data=[go.Pie(
                    labels=chart_data['names'], 
                    values=chart_data['values'],
                    title=insight['title']
                )])
            else:
                fig = px.scatter(self.df.head(100), title=insight['title'])  # Fallback
                
            fig.update_layout(height=400)
            return fig
            
        except Exception as e:
            # Return empty figure on error
            fig = go.Figure()
            fig.add_annotation(text=f"Chart unavailable: {str(e)[:50]}...", 
                             x=0.5, y=0.5, showarrow=False)
            fig.update_layout(title=insight['title'], height=400)
            return fig
    
    def _get_insight_color(self, insight_type: str) -> str:
        """Get color for insight type"""
        color_map = {
            'metric': 'primary',
            'relationship': 'info',
            'trend': 'success',
            'distribution': 'secondary',
            'business': 'warning',
            'anomaly': 'danger'
        }
        return color_map.get(insight_type, 'light')

# Usage Example
def create_insights_dashboard(df: pd.DataFrame, user_question: str) -> Dash:
    """Main function to create insights dashboard"""
    
    # Generate insights
    insights_generator = AutomatedInsightsGenerator(df, user_question)
    insights = insights_generator.generate_insights()
    
    # Create dashboard
    dashboard = InsightsDashboard(df, insights)
    app = dashboard.create_dashboard()
    
    return app

# Example usage:
"""
# After getting DataFrame from SQL query
df = your_dataframe_from_sql_query
user_question = "show me the relation between new and renewal policies"

app = create_insights_dashboard(df, user_question)
app.run_server(debug=True)
"""