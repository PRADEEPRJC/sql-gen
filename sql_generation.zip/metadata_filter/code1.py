import spacy
from difflib import get_close_matches

# Load spaCy English model
nlp = spacy.load("en_core_web_sm")

# -------------------------
# Example Metadata
# -------------------------

direct_fields = {
    "table1.column1": "Policy Number",
    "table1.year": "Year",
    "table1.month": "Month",
    "table1.region": "Region",
    "table2.policy_flag": "Policy Flag"
}

derived_fields = {
    "policy_type": {
        "logic": "IFF(policy_flag=1,'new','renewal')",
        "source_columns": ["table2.policy_flag"]
    }
}

join_conditions = ["table1.id = table2.id"]

# Common dashboard filter aliases (expand as needed)
filter_candidates = ["year", "month", "quarter", "date", "region", "state", "city", "policy type"]

# -------------------------
# Step 1: Extract keywords from question
# -------------------------

def extract_keywords(question: str):
    doc = nlp(question.lower())
    keywords = [token.text for token in doc if token.pos_ in ["NOUN", "PROPN", "ADJ"]]
    return list(set(keywords))

# -------------------------
# Step 2: Match keywords to Direct + Derived fields
# -------------------------

def match_fields(keywords, direct_fields, derived_fields):
    matched_direct = {}
    matched_derived = {}

    # Match direct fields
    for src_col, alias in direct_fields.items():
        for kw in keywords:
            if kw in alias.lower():
                matched_direct[src_col] = alias
            else:
                # fuzzy match
                close = get_close_matches(kw, [alias.lower()], cutoff=0.8)
                if close:
                    matched_direct[src_col] = alias

    # Match derived fields
    for dfield, dmeta in derived_fields.items():
        for kw in keywords:
            if kw in dfield.lower() or kw in dmeta["logic"].lower():
                matched_derived[dfield] = dmeta

    # Expand derived field dependencies
    for dfield, dmeta in matched_derived.items():
        for src_col in dmeta["source_columns"]:
            if src_col in direct_fields:
                matched_direct[src_col] = direct_fields[src_col]

    return matched_direct, matched_derived

# -------------------------
# Step 3: Detect filters
# -------------------------

def detect_filters(keywords, direct_fields):
    filters = []
    for kw in keywords:
        for src_col, alias in direct_fields.items():
            if kw in alias.lower():
                if any(fc in alias.lower() for fc in filter_candidates):
                    filters.append(src_col)
    return list(set(filters))

# -------------------------
# Step 4: Reduced Metadata Builder
# -------------------------

def reduce_metadata(question, direct_fields, derived_fields, join_conditions):
    keywords = extract_keywords(question)
    matched_direct, matched_derived = match_fields(keywords, direct_fields, derived_fields)
    filters = detect_filters(keywords, matched_direct)

    return {
        "DirectFields": matched_direct,
        "DerivedFields": matched_derived,
        "JoinCondition": join_conditions,
        "Filters": filters
    }

# -------------------------
# Example Run
# -------------------------

question = "What is the policy count for new and renewal policies by year and month in each region?"
reduced_metadata = reduce_metadata(question, direct_fields, derived_fields, join_conditions)

import json
print(json.dumps(reduced_metadata, indent=2))

