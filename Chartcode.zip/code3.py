PROMPT_TEMPLATE = """You are a P&C Insurance Data Visualization Expert. Your task is to generate JSON chart parameters for the Plotly library based on a user's question and the provided data metadata.

**Goal:**
Generate a single JSON object that defines a chart's type, data mapping, layout, and filters.

**Available Chart Types and Use Cases:**

* **`line`**: Use for trend analysis over a continuous variable, typically time (e.g., premium over months).

* **`bar`**: Use for categorical comparisons (e.g., claims by product line, premium by state).

* **`scatter`**: Use to analyze the relationship between two numerical variables (e.g., loss ratio vs. written premium).

* **`pie`**: Use to show the composition of a whole (e.g., percentage of policies by product).

* **`histogram`**: Use to show the distribution of a single numerical variable (e.g., frequency of different claim amounts).

* **`box`**: Use to compare the variability and central tendency of a numerical variable across different categories (e.g., loss ratio by region).

* **`area`**: Use to show stacked trends over time.

* **`choropleth`**: Use for geographic analysis (requires a `state_code` column).

**Input:**

1. **User Question:** A natural language query describing the desired visualization.
   `{user_question}`

2. **Dataframe Metadata:** A JSON object detailing the columns and their data types.
   `{data_metadata}`

**Output Structure:**

Your output **must be ONLY** a single, valid JSON object following this schema.

```
{
  "chart_type": "line|bar|scatter|pie|histogram|box|area|choropleth",
  "data_config": {
    "x": "column_name",
    "y": "column_name",
    "color": "column_name_optional"
  },
  "layout_config": {
    "title": "Chart Title",
    "xaxis": {
      "title": "X-axis Title"
    },
    "yaxis": {
      "title": "Y-axis Title"
    }
  },
  "filters": {
    "column_name": "value_to_filter"
  }
}


```

**Instructions:**

1. Analyze the `User Question` and `Dataframe Metadata` to determine the most suitable `chart_type`.

2. Map the appropriate columns from the `Dataframe Metadata` to the `x` and `y` keys in the `data_config`.

   * If the user asks for a comparison across a category (e.g., product line), use that column for the `x` axis and the metric (e.g., written premium) for the `y` axis.

   * If the user asks for a relationship, use the two numerical columns for `x` and `y`.

   * If a third variable is mentioned for segmentation, use it for the `color` key.

3. Populate `layout_config` with a clear, descriptive `title` and titles for the `xaxis` and `yaxis`.

4. If the user's question implies a filter (e.g., "for the auto product"), add the filter criteria to the `filters` object.

5. Output ONLY the final JSON object. Do not include any explanations, code, or conversational text before or after the JSON.
"""


import plotly.express as px
import pandas as pd
import json

def generate_chart(llm_output_json, data_df):
    """
    Generates a Plotly chart from LLM-generated JSON parameters.

    Args:
        llm_output_json (str): A JSON string from the LLM containing chart configuration.
        data_df (pd.DataFrame): The pandas DataFrame with the data to be plotted.

    Returns:
        plotly.graph_objects.Figure: The generated Plotly figure object.
    """
    try:
        config = json.loads(llm_output_json)
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON: {e}")
        return None

    chart_type = config.get("chart_type")
    data_config = config.get("data_config", {})
    layout_config = config.get("layout_config", {})

    x_col = data_config.get("x")
    y_col = data_config.get("y")
    color_col = data_config.get("color")
    title = layout_config.get("title", "")
    
    # Check for required columns in the DataFrame
    if x_col not in data_df.columns or y_col not in data_df.columns:
        print("Error: Required columns not found in the DataFrame.")
        return None

    fig = None
    if chart_type == "bar":
        fig = px.bar(data_df, x=x_col, y=y_col, color=color_col, title=title)
    elif chart_type == "line":
        fig = px.line(data_df, x=x_col, y=y_col, color=color_col, title=title)
    elif chart_type == "scatter":
        fig = px.scatter(data_df, x=x_col, y=y_col, color=color_col, title=title)
    elif chart_type == "pie":
        fig = px.pie(data_df, names=x_col, values=y_col, title=title)
    elif chart_type == "histogram":
        fig = px.histogram(data_df, x=x_col, title=title)
    else:
        print(f"Unsupported chart type: {chart_type}")

    if fig:
        # Update layout properties if they exist
        if "xaxis" in layout_config:
            fig.update_xaxes(title_text=layout_config["xaxis"].get("title", x_col))
        if "yaxis" in layout_config:
            fig.update_yaxes(title_text=layout_config["yaxis"].get("title", y_col))

    return fig

if __name__ == "__main__":
    # Example usage:
    # 1. Mock the LLM output (what you would get from the prompt)
    llm_output = """{
        "chart_type": "bar",
        "data_config": {
            "x": "product_line",
            "y": "written_premium",
            "color": null
        },
        "layout_config": {
            "title": "Written Premium by Product Line",
            "xaxis": {
                "title": "Product Line"
            },
            "yaxis": {
                "title": "Written Premium ($)"
            }
        },
        "filters": {}
    }"""

    # 2. Mock the data DataFrame
    data = {
        "product_line": ["Auto", "Home", "Commercial", "Auto", "Home"],
        "written_premium": [500000, 300000, 700000, 650000, 350000],
        "state": ["CA", "NY", "TX", "CA", "NY"]
    }
    df = pd.DataFrame(data)

    # 3. Generate and display the chart
    chart = generate_chart(llm_output, df)
    if chart:
        chart.show()
