import spacy
from difflib import SequenceMatcher
import re

# Load spaCy model (assuming 'en_core_web_sm' is installed)
nlp = spacy.load("en_core_web_sm")

def filter_metadata(query, full_metadata):
    """
    Filters metadata based on the query using spaCy for preprocessing and matching.
    If no relevant matches found, returns the full metadata.
    
    Args:
    query (str): The natural language query.
    full_metadata (dict): {
        'direct': list of dicts e.g., [{'Source Table': 'table1', 'Source Column': 'column1', 'Alias Name': 'column 1'}],
        'derived': list of dicts e.g., [{'Source Table Source Columns': 'table1 column1,column2,column3', 
                                        'Transformation Logic': 'iff(column1==1,column2,column3)'}],
        'joins': str or dict for join conditions (optional, always included if present)
    }
    
    Returns:
    dict: Filtered metadata or full if no matches.
    """
    # Preprocess query with spaCy
    doc = nlp(query.lower())
    key_terms = []
    for token in doc:
        if not token.is_stop and token.pos_ in ['NOUN', 'PROPN', 'VERB']:
            key_terms.append(token.lemma_)
    
    # Add NER entities if any
    for ent in doc.ents:
        if ent.label_ in ['DATE', 'ORG', 'GPE']:  # Relevant types
            key_terms.append(ent.text.lower())
    
    key_terms = list(set(key_terms))  # Unique terms
    
    if not key_terms:
        return full_metadata  # Fallback if no terms extracted
    
    filtered = {'direct': [], 'derived': []}
    if 'joins' in full_metadata:
        filtered['joins'] = full_metadata['joins']  # Always include joins
    
    has_matches = False
    
    # Helper function for matching
    def matches_term(text, terms, sim_threshold=0.7):
        text_doc = nlp(text.lower())
        for term in terms:
            term_doc = nlp(term)
            semantic_sim = text_doc.similarity(term_doc)
            fuzzy_sim = SequenceMatcher(None, text.lower(), term).ratio()
            combined_sim = max(semantic_sim, fuzzy_sim)
            if combined_sim >= sim_threshold:
                return True
        return False
    
    # Match direct fields
    for field in full_metadata.get('direct', []):
        alias = field.get('Alias Name', '').lower()
        column = field.get('Source Column', '').lower()
        table = field.get('Source Table', '').lower()
        match_text = f"{alias} {column} {table}"
        if matches_term(match_text, key_terms):
            filtered['direct'].append(field)
            has_matches = True
    
    # Match derived fields
    for field in full_metadata.get('derived', []):
        columns_str = field.get('Source Table Source Columns', '').lower()
        logic = field.get('Transformation Logic', '').lower()
        # Extract columns from string (assuming space or comma separated)
        columns = re.split(r'[,\s]+', columns_str.strip())
        match_text = ' '.join(columns) + ' ' + logic
        if matches_term(match_text, key_terms):
            filtered['derived'].append(field)
            has_matches = True
    
    # Fallback if no matches
    if not has_matches:
        return full_metadata
    
    return filtered

# Example usage (for testing)
if __name__ == "__main__":
    example_metadata = {
        'direct': [
            {'Source Table': 'table1', 'Source Column': 'column1', 'Alias Name': 'column 1'},
            # Add more as needed
        ],
        'derived': [
            {'Source Table Source Columns': 'table1 column1,column2,column3', 
             'Transformation Logic': 'iff(column1==1,column2,column3)'},
            # Add more
        ],
        'joins': 'table1.id = table2.id'  # Example join
    }
    example_query = "what is the policy count for new and renewal policies?"
    filtered = filter_metadata(example_query, example_metadata)
    print(filtered)