import dash
from dash import dcc, no_update
import dash_mantine_components as dmc
from dash.dependencies import Input, Output, State
import threading
import time

from progress import get_progress_status, update_step
from stepper import create_stepper_steps
from pages.sql import sql_page
from pages.data import data_page
from pages.dashboard import dashboard_page

app = dash.Dash(__name__, suppress_callback_exceptions=True)


# 🔹 Background simulation
def background_process(user_input):
    # Step 1: SQL
    update_step("sql", "in_progress")
    time.sleep(10)
    update_step("sql", "completed")

    # Step 2: Data
    update_step("data", "in_progress")
    time.sleep(10)
    update_step("data", "completed")

    # Step 3: Dashboard with failures & retries
    update_step("dashboard", "in_progress")
    time.sleep(10)
    update_step("dashboard", "failed", retry=1)

    time.sleep(10)
    update_step("dashboard", "failed", retry=2)

    time.sleep(10)
    update_step("dashboard", "completed")


# 🔹 Layout
app.layout = dmc.MantineProvider([
    dcc.Location(id="url", refresh=False),
    dcc.Interval(id="progress-interval", interval=2000, n_intervals=0),
    dmc.Container(id="page-content", size="lg", mt=20)
])


# 🔹 Routing
@app.callback(
    Output("page-content", "children"),
    Input("url", "pathname")
)
def display_page(pathname):
    if pathname == "/sql":
        return sql_page()
    elif pathname == "/data":
        return data_page()
    elif pathname == "/dashboard":
        return dashboard_page()
    else:
        return create_main_page()


# 🔹 Main page
def create_main_page():
    progress = get_progress_status()
    stepper_steps = create_stepper_steps(progress)

    return dmc.Container([
        dmc.Title("Background Process Stepper", order=2, mb=20),
        dmc.Paper([
            dmc.Textarea(
                id="user-input-visible",
                label="Enter your query:",
                placeholder="Describe analysis...",
                minRows=3,
                mb=20
            ),
            dmc.Group([
                dmc.Button("Submit", id="submit-btn-visible", color="blue"),
                dmc.Button("Clear Progress", id="clear-btn-visible", color="red", variant="outline")
            ], mb=20),
            dmc.Stepper(
                active=progress.get("active_step", 0),
                orientation="vertical",
                size="lg",
                children=stepper_steps
            )
        ], p=20, shadow="sm")
    ], size="lg", mt=20)


# 🔹 Submit action → starts background thread
@app.callback(
    Output("submit-btn-visible", "disabled"),
    Input("submit-btn-visible", "n_clicks"),
    State("user-input-visible", "value"),
    prevent_initial_call=True
)
def start_process(n_clicks, user_input):
    if n_clicks and user_input:
        thread = threading.Thread(target=background_process, args=(user_input,))
        thread.daemon = True
        thread.start()
        return True
    return no_update


if __name__ == "__main__":
    app.run(debug=True, port=8050)
