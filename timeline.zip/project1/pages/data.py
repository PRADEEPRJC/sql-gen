import dash_mantine_components as dmc

def data_page():
    return dmc.Container([
        dmc.Title("Data Page", order=2),
        dmc.Text("Here is the fetched data preview."),
        dmc.CodeHighlight(code="policy_id | amount\n1 | 100\n2 | 200", language="sql")
    ], size="lg", mt=20)
