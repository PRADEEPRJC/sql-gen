import dash
from dash import dcc, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import threading
import time
import os
import json
from datetime import datetime

app = dash.Dash(__name__, suppress_callback_exceptions=True)

PROGRESS_FILES = {
    'sql.txt': 'SQL Query Generated',
    'data.txt': 'SQL Executed', 
    'chart.txt': 'Dashboard Created'
}

PROGRESS_FILE = 'progress_status.json'

def get_progress_status():
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {
        'active_step': -1,
        'completed_steps': [],
        'in_progress': False,
        'start_time': None
    }

def save_progress_status(status):
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(status, f)

def background_process(user_input):
    status = {
        'active_step': 0,
        'completed_steps': [],
        'in_progress': True,
        'start_time': datetime.now().isoformat(),
        'user_input': user_input
    }
    save_progress_status(status)
    
    files_to_create = list(PROGRESS_FILES.keys())
    
    for i, filename in enumerate(files_to_create):
        time.sleep(10)
        with open(filename, 'w') as f:
            f.write(f"Step {i+1} completed at {datetime.now()}\nUser input: {user_input}")
        status = get_progress_status()
        status['completed_steps'].append(i)
        status['active_step'] = i + 1 if i < len(files_to_create) - 1 else -1
        if i == len(files_to_create) - 1:
            status['in_progress'] = False
        save_progress_status(status)

def get_icon(icon, size=20):
    return DashIconify(icon=icon, height=size)

def create_stepper_steps(active_step, completed_steps):
    steps_config = [
        {
            "label": "SQL Query Generated",
            "icon": "material-symbols:code",
            "progress_icon": "material-symbols:code",
            "completed_icon": "material-symbols:code-blocks",
            "page": "/sql"
        },
        {
            "label": "SQL Executed", 
            "icon": "material-symbols:database",
            "progress_icon": "material-symbols:database",
            "completed_icon": "material-symbols:database-export",
            "page": "/data"
        },
        {
            "label": "Dashboard Created",
            "icon": "material-symbols:dashboard",
            "progress_icon": "material-symbols:dashboard",
            "completed_icon": "material-symbols:dashboard-customize",
            "page": "/chart"
        }
    ]

    steps = []
    for i, step_config in enumerate(steps_config):
        is_completed = i in completed_steps
        is_active = i == active_step
        is_loading = is_active

        if is_completed:
            description = dmc.Stack([
                dmc.Text(f"{step_config['label']} completed successfully!", size="sm", c="green"),
                dmc.Anchor("View Details", href=step_config["page"], fw=500, fz="sm", c="blue")
            ], gap="xs")
            content = dmc.Alert(dmc.Text("Step completed successfully!", size="sm"), color="green", variant="light")
        elif is_active:
            description = dmc.Text("Step in progress...", size="sm", c="blue")
            content = dmc.Alert(dmc.Text("Step in progress...", size="sm"), color="blue", variant="light")
        else:
            description = dmc.Text("Waiting to start...", c="dimmed", size="sm")
            content = dmc.Text("Waiting to start...", c="dimmed", size="sm")

        step = dmc.StepperStep(
            label=step_config["label"],
            description=description,
            icon=get_icon(step_config["icon"]),
            progressIcon=get_icon(step_config["progress_icon"]),
            completedIcon=get_icon(step_config["completed_icon"]),
            loading=is_loading,
            children=[content]
        )
        steps.append(step)

    if len(completed_steps) == 3:
        steps.append(
            dmc.StepperCompleted(
                children=[
                    dmc.Alert(
                        [
                            dmc.Text("🎉 All steps completed successfully!", size="lg", fw=500),
                            dmc.Anchor("Go to Dashboard", href="/chart", fw=600, c="blue", mt=5)
                        ],
                        color="green",
                        variant="filled"
                    )
                ]
            )
        )
    return steps

app.layout = dmc.MantineProvider([
    dcc.Location(id='url', refresh=False),
    dcc.Interval(id='progress-interval', interval=2000, n_intervals=0),
    dmc.Stack(id='page-content')
])

def create_main_page():
    return dmc.Container([
        dmc.Title("Background Process Stepper", order=2, mb=20),
        dmc.Paper([
            dmc.Textarea(
                id='user-input-visible',
                label="Enter your query or description:",
                placeholder="Describe what you want to analyze...",
                minRows=3,
                mb=20
            ),
            dmc.Group([
                dmc.Button("Submit", id="submit-btn-visible", color="blue", leftSection=get_icon("material-symbols:play-arrow")),
                dmc.Button("Go to Dashboard", id="dashboard-btn-visible", color="gray", variant="outline", leftSection=get_icon("material-symbols:dashboard")),
                dmc.Button("Clear Progress", id="clear-btn-visible", color="red", variant="outline", leftSection=get_icon("material-symbols:refresh"))
            ], mb=20),
            dmc.Stack(id="stepper-container-visible")
        ], p=20, shadow="sm")
    ], size="lg", mt=20)

def create_dashboard_page():
    return dmc.Container([
        dmc.Title("Dashboard Report Page", order=2, mb=20),
        dmc.Paper([
            dmc.Group([
                get_icon("material-symbols:dashboard", 40),
                dmc.Stack([
                    dmc.Text("Dashboard Report", size="xl", fw=500),
                    dmc.Text("This is a sample dashboard page.", size="md", c="dimmed")
                ])
            ], mb=20),
            dmc.Alert([
                dmc.Text("📊 The background process continues running while you're here.", size="sm"),
                dmc.Text("Return to the main page to check progress status.", size="sm", mt=5)
            ], color="blue", variant="light", mb=20),
            dmc.Button("Back to Progress", id="back-btn-visible", color="blue", leftSection=get_icon("material-symbols:arrow-back"))
        ], p=20, shadow="sm")
    ], size="lg", mt=20)

@app.callback(Output('page-content', 'children'), Input('url', 'pathname'))
def display_page(pathname):
    if pathname == '/dashboard':
        return create_dashboard_page()
    elif pathname == '/sql':
        return dmc.Container([dmc.Title("SQL Query Page", order=2), dmc.Text("SQL file generated.")], size="lg", mt=20)
    elif pathname == '/data':
        return dmc.Container([dmc.Title("Data Page", order=2), dmc.Text("Data file generated.")], size="lg", mt=20)
    elif pathname == '/chart':
        return create_dashboard_page()
    else:
        return create_main_page()

@app.callback(Output('url', 'pathname'), Input('dashboard-btn-visible', 'n_clicks'), prevent_initial_call=True)
def navigate_to_dashboard(n_clicks):
    if n_clicks:
        return '/dashboard'
    return no_update

@app.callback(Output('url', 'pathname', allow_duplicate=True), Input('back-btn-visible', 'n_clicks'), prevent_initial_call=True)
def navigate_to_home(n_clicks):
    if n_clicks:
        return '/'
    return no_update

@app.callback([Output('submit-btn-visible', 'disabled'), Output('clear-btn-visible', 'disabled')], Input('submit-btn-visible', 'n_clicks'), State('user-input-visible', 'value'), prevent_initial_call=True)
def start_background_process(n_clicks, user_input):
    if n_clicks and user_input:
        thread = threading.Thread(target=background_process, args=(user_input,))
        thread.daemon = True
        thread.start()
        return True, True
    return no_update, no_update

@app.callback([Output('user-input-visible', 'value'), Output('submit-btn-visible', 'disabled', allow_duplicate=True), Output('clear-btn-visible', 'disabled', allow_duplicate=True)], Input('clear-btn-visible', 'n_clicks'), prevent_initial_call=True)
def clear_progress(n_clicks):
    if n_clicks:
        files_to_remove = list(PROGRESS_FILES.keys()) + [PROGRESS_FILE]
        for file in files_to_remove:
            if os.path.exists(file):
                os.remove(file)
        return "", False, False
    return no_update, no_update, no_update

@app.callback(Output('stepper-container-visible', 'children'), [Input('progress-interval', 'n_intervals'), Input('url', 'pathname')])
def update_stepper(n_intervals, pathname):
    if pathname != '/' and pathname is not None:
        return no_update

    status = get_progress_status()
    if not status['in_progress'] and not status['completed_steps'] and status['active_step'] == -1:
        return dmc.Alert(
            dmc.Group([
                get_icon("material-symbols:info", 24),
                dmc.Stack([
                    dmc.Text("Ready to start", size="lg", fw=500),
                    dmc.Text("Click Submit to begin the process", size="sm")
                ], gap="xs")
            ]),
            color="blue", variant="light", mt=30
        )

    if not status['in_progress'] and len(status['completed_steps']) == 3:
        active_stepper_step = 3
    else:
        active_stepper_step = len(status['completed_steps'])

    stepper_steps = create_stepper_steps(status['active_step'], status['completed_steps'])

    status_elements = []
    if status['in_progress']:
        status_elements.append(
            dmc.Alert([
                get_icon("material-symbols:hourglass-empty", 20),
                dmc.Text("Process is running in background...", ml=10)
            ], color="blue", variant="light", mt=20)
        )
    elif len(status['completed_steps']) == 3:
        status_elements.append(
            dmc.Alert([
                get_icon("material-symbols:check-circle", 20),
                dmc.Text("All steps completed successfully!", style={"marginLeft": "10px"})
            ], color="green", variant="light", mt=20)
        )

    if status.get('start_time'):
        status_elements.append(
            dmc.Text(f"Started at: {status['start_time'][:19].replace('T', ' ')}", c="dimmed", size="xs", mt=10)
        )

    return dmc.Stack([
        dmc.Stepper(active=active_stepper_step, orientation="vertical", size="lg", children=stepper_steps),
        dmc.Stack(status_elements)
    ])

@app.callback([Output('submit-btn-visible', 'disabled', allow_duplicate=True), Output('clear-btn-visible', 'disabled', allow_duplicate=True)], Input('progress-interval', 'n_intervals'), prevent_initial_call=True)
def update_button_states(n_intervals):
    status = get_progress_status()
    return status['in_progress'], status['in_progress']

if __name__ == '__main__':
    app.run(debug=True, port=8050)