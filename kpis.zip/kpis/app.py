import dash
from dash import html, Input, Output, State, dcc
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import plotly.express as px
import pandas as pd

# Sample KPI data
kpi_data = [
    {"label": "New Business Policy Count", "value": 1200, "icon": "mdi:file-document-outline"},
    {"label": "Renewal Count", "value": 950, "icon": "mdi:autorenew"},
    {"label": "New Business Premium", "value": 1_250_000, "icon": "mdi:cash"},
    {"label": "Cancellation Ratio", "value": 3.2, "icon": "mdi:cancel", "is_percent": True},
    {"label": "Claims Filed", "value": 320, "icon": "mdi:file-alert"},
    {"label": "Claims Approved", "value": 280, "icon": "mdi:check-circle"},
    {"label": "Average Claim Amount", "value": 15_000, "icon": "mdi:currency-usd"},
    {"label": "Customer Satisfaction", "value": 89, "icon": "mdi:emoticon-happy", "is_percent": True},
    {"label": "Policy Lapse Rate", "value": 1.8, "icon": "mdi:alert", "is_percent": True},
    {"label": "Agent Performance Score", "value": 92, "icon": "mdi:star", "is_percent": True},
]

# Sample historical data for charts
def generate_chart(label):
    df = pd.DataFrame({
        "Month": ["Jan", "Feb", "Mar", "Apr", "May"],
        "Value": [1000, 1100, 950, 1200, 1250]
    })
    fig = px.line(df, x="Month", y="Value", title=f"{label} Trend")
    return dcc.Graph(figure=fig)

# KPI Card Generator
def generate_kpi_card(kpi, format_type):
    value = kpi["value"]
    is_percent = kpi.get("is_percent", False)

    if format_type == "currency" and not is_percent:
        formatted = dmc.NumberFormatter(value=value, thousandSeparator=True, prefix="$ ")
    elif format_type == "percent" and is_percent:
        formatted = f"{value}%"
    else:
        formatted = value

    return dmc.Card(
        children=[
            dmc.CardSection(
                dmc.Group(
                    children=[
                        DashIconify(icon=kpi["icon"], width=30),
                        dmc.Text(kpi["label"], fw=600),
                        dmc.ActionIcon(
                            DashIconify(icon="mdi:information-outline"),
                            id={"type": "info-btn", "index": kpi["label"]},
                            variant="light",
                        ),
                    ],
                    justify="space-between",
                ),
                withBorder=True,
                inheritPadding=True,
                py="xs",
            ),
            dmc.Text(
                children=[
                    dmc.Text(
                        formatted,
                        style={"fontSize": "1.5rem", "fontWeight": "bold"},
                    )
                ],
                mt="sm",
                c="dimmed",
                size="sm",
            ),
        ],
        withBorder=True,
        shadow="sm",
        radius="md",
        w=300,
    )

# App setup
app = dash.Dash(__name__)
app.layout = dmc.MantineProvider(
    theme={"colorScheme": "light"},
    id="theme-provider",
    children=dmc.Container(
        size="xl",
        px="md",
        children=[
            dmc.Title("Insurance KPI Dashboard", order=2, mb="md"),
            dmc.Group([
                dmc.NumberInput(
                    id="kpi-count",
                    label="Number of KPIs",
                    min=1,
                    max=10,
                    value=5,
                    step=1,
                    style={"width": 200},
                ),
                dmc.SegmentedControl(
                    id="format-toggle",
                    value="currency",
                    data=["currency", "percent"],
                    style={"width": 200},
                ),
                dmc.Switch(
                    id="dark-toggle",
                    label="Dark Mode",
                    size="md",
                ),
            ], mb="lg"),
            dmc.SimpleGrid(id="kpi-grid", cols=3, spacing="lg"),
            dmc.Modal(
                id="drilldown-modal",
                title="KPI Details",
                centered=True,
                size="lg",
                children=dmc.Box(
                    id="modal-content",
                    children=[],
                    style={"position": "relative"},
                ),
            ),
            dmc.LoadingOverlay(
                id="modal-loader",
                visible=False,
                overlayProps={"blur": 2},
                zIndex=1000,
            ),
        ],
    )
)

# Update KPI grid
@app.callback(
    Output("kpi-grid", "children"),
    Input("kpi-count", "value"),
    Input("format-toggle", "value"),
)
def update_kpi_grid(count, format_type):
    return [generate_kpi_card(kpi, format_type) for kpi in kpi_data[:count]]

# Toggle dark mode
@app.callback(
    Output("theme-provider", "theme"),
    Input("dark-toggle", "checked"),
)
def toggle_theme(is_dark):
    return {"colorScheme": "dark" if is_dark else "light"}

# Open modal with chart
@app.callback(
    Output("drilldown-modal", "opened"),
    Output("modal-content", "children"),
    Output("modal-loader", "visible"),
    Input({"type": "info-btn", "index": dash.ALL}, "n_clicks"),
    State({"type": "info-btn", "index": dash.ALL}, "id"),
    prevent_initial_call=True
)
def open_modal(n_clicks, ids):
    ctx = dash.callback_context
    if not ctx.triggered:
        return False, [], False
    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0]
    label = eval(triggered_id)["index"]
    chart = generate_chart(label)
    return True, chart, False

if __name__ == "__main__":
    app.run(debug=True)
