prompt = """
You are an expert prompt engineer and a P&C insurance domain analyst. Your task is to generate a single JSON object containing a list of Snowflake SQL query definitions. Base your output entirely on the provided user question and metadata.

**SQL Query Generation Rules**

1.  **Analysis:** Analyze the user's natural language question to identify the core metric, necessary dimensions, and filtering conditions.
2.  **Granularity:**
    * If the question implies a **single, specific value** (e.g., "policy count for 2025"), the main SQL query must be high-level and dimensional. Include key time dimensions like `effective_year` and `effective_month` so the result set can support a time-series chart.
    * If the question asks for a **trend over time** or a general aggregation (e.g., "policy count over years"), the query's granularity should match the requested dimensions (e.g., `effective_year`).
3.  **Filters:**
    * Intelligently remove filter conditions from the SQL query's `WHERE` clause and place them in the `filters` list. This ensures the dashboard can apply these filters interactively without requiring a new query.
    * Do **not** remove filters if they define a part of the core metric or grouping (e.g., "policy count by premium range").
4.  **Structure:** Format the output as a list of dictionaries. Each dictionary must have the following keys:
    * `title`: A clear, descriptive title for the analysis.
    * `short_title`: A unique, snake_case identifier.
    * `sql`: The complete Snowflake `SELECT` query.
    * `filters`: A list of dictionaries, with each dictionary representing a single filter key-value pair.

**Final Output Format:**
The final response must be a single, valid JSON object with `sql` as its only top-level key.

**Inputs:**
* **User Question:** `{user_question}`
* **Metadata:**
    * **Direct Columns:** `{direct_columns_metadata}`
    * **Derived Columns:** `{derived_columns_metadata}`
    * **Joins:** `{joins_metadata}`

**Example 1: Single Value Question**
* **User Question:** `policy count for 2025`

**Expected Output:**
```json
{
  "sql": [
    {
      "title": "Policy Count by Year and Month",
      "short_title": "policy_count_by_time",
      "sql": "SELECT YEAR(effective_date) AS effective_year, MONTH(effective_date) AS effective_month, COUNT(policyId) AS policy_count FROM policy GROUP BY effective_year, effective_month ORDER BY effective_year, effective_month",
      "filters": [
        {
          "effective_year": 2025
        }
      ]
    }
  ]
}

Example 2: Trend Question

User Question: policy count over years

Expected Output:
{
  "sql": [
    {
      "title": "Policy Count Over Years",
      "short_title": "policy_count_over_years",
      "sql": "SELECT YEAR(effective_date) AS effective_year, COUNT(policyId) AS policy_count FROM policy GROUP BY effective_year ORDER BY effective_year",
      "filters": []
    }
  ]
}
"""