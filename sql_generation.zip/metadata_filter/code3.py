import spacy
from typing import List, Dict

# -----------------------------
# 1. Load spaCy model
# -----------------------------
nlp = spacy.load("en_core_web_sm")

# -----------------------------
# 2. Example metadata
# -----------------------------
direct_fields = [
    {"SourceTable": "table1", "SourceColumn": "policy_type", "AliasName": "policy type"},
    {"SourceTable": "table1", "SourceColumn": "year", "AliasName": "year"},
    {"SourceTable": "table1", "SourceColumn": "month", "AliasName": "month"},
    {"SourceTable": "table2", "SourceColumn": "status", "AliasName": "status"}
]

derived_fields = [
    {
        "SourceTable": "table1",
        "SourceColumns": "policy_type",
        "DerivedName": "new policy count",
        "TransformationLogic": "COUNT(CASE WHEN policy_type='new' THEN 1 END)"
    },
    {
        "SourceTable": "table1",
        "SourceColumns": "policy_type",
        "DerivedName": "renewal policy count",
        "TransformationLogic": "COUNT(CASE WHEN policy_type='renewal' THEN 1 END)"
    }
]

join_conditions = ["table1.id = table2.id"]

# -----------------------------
# 3. Keyword extraction
# -----------------------------
def extract_keywords(query: str) -> List[str]:
    doc = nlp(query.lower())
    keywords = set()
    for token in doc:
        if token.pos_ in {"NOUN", "PROPN", "VERB", "ADJ", "NUM"}:
            keywords.add(token.lemma_)
    return list(keywords)

# -----------------------------
# 4. Scoring function
# -----------------------------
def score_field(field: Dict, keywords: List[str], name_keys: List[str], logic_keys: List[str] = None) -> int:
    score = 0
    for k in keywords:
        if any(k in nk for nk in name_keys):
            score += 3  # higher weight for alias/derived name match
        if logic_keys and any(k in lk for lk in logic_keys):
            score += 1  # lower weight for transformation logic match
    return score

# -----------------------------
# 5. Filter + rank metadata
# -----------------------------
def filter_and_rank_metadata(query: str,
                             direct_fields: List[Dict],
                             derived_fields: List[Dict],
                             join_conditions: List[str],
                             top_n: int = None) -> Dict:
    keywords = extract_keywords(query)
    
    scored_direct = []
    scored_derived = []
    
    # Direct fields scoring
    for field in direct_fields:
        score = score_field(field, keywords,
                            [field["AliasName"].lower(), field["SourceColumn"].lower()])
        if score > 0:
            scored_direct.append((score, field))
    
    # Derived fields scoring
    for field in derived_fields:
        score = score_field(field, keywords,
                            [field["DerivedName"].lower()],
                            [field["TransformationLogic"].lower()])
        if score > 0:
            scored_derived.append((score, field))
            # Include source columns in direct fields if not already present
            for col in field["SourceColumns"].split(","):
                col = col.strip().lower()
                for df in direct_fields:
                    if df["SourceColumn"].lower() == col:
                        if not any(df == f for _, f in scored_direct):
                            scored_direct.append((score, df))
    
    # Sort by score (descending)
    scored_direct.sort(key=lambda x: x[0], reverse=True)
    scored_derived.sort(key=lambda x: x[0], reverse=True)
    
    # Keep only top N if specified
    if top_n:
        scored_direct = scored_direct[:top_n]
        scored_derived = scored_derived[:top_n]
    
    return {
        "DirectFields": [f for _, f in scored_direct],
        "DerivedFields": [f for _, f in scored_derived],
        "JoinConditions": join_conditions
    }

# -----------------------------
# 6. Example usage
# -----------------------------
user_query = "What is the policy count for new and renewal policies by year and month?"
filtered_ranked_meta = filter_and_rank_metadata(user_query, direct_fields, derived_fields, join_conditions, top_n=5)

print(filtered_ranked_meta)
