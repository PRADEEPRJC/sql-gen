import dash
from dash import dcc
from dash import html, Input, Output
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import pandas as pd
import numpy as np
import plotly.express as px

# Sample KPI data
kpi_data = [
    {"label": "New Business Policy Count", "value": 1200, "icon": "mdi:file-document-outline"},
    {"label": "Renewal Count", "value": 950, "icon": "mdi:autorenew"},
    {"label": "New Business Premium", "value": 1_250_000, "icon": "mdi:cash"},
    {"label": "Cancellation Ratio", "value": 3.2, "icon": "mdi:cancel", "is_percent": True},
    {"label": "Claims Filed", "value": 320, "icon": "mdi:file-alert"},
    {"label": "Claims Approved", "value": 280, "icon": "mdi:check-circle"},
    {"label": "Average Claim Amount", "value": 15_000, "icon": "mdi:currency-usd"},
    {"label": "Customer Satisfaction", "value": 89, "icon": "mdi:emoticon-happy", "is_percent": True},
    {"label": "Policy Lapse Rate", "value": 1.8, "icon": "mdi:alert", "is_percent": True},
    {"label": "Agent Performance Score", "value": 92, "icon": "mdi:star", "is_percent": True},
]

# Generate sample sparkline data
def generate_sparkline_data():
    return pd.DataFrame({"x": list(range(7)), "y": np.random.randint(50, 200, 7)})

# Card generators for different styles
def minimal_card(kpi):
    return dmc.Card(
        withBorder=True, shadow="sm", radius="md", w=250,
        children=[
            dmc.Group([DashIconify(icon=kpi["icon"], width=30), dmc.Text(kpi["label"], fw=600)], justify="space-between"),
            dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)

        ]
    )

def badge_card(kpi):
    color = "green" if np.random.rand() > 0.5 else "red"
    badge_text = "Up" if color=="green" else "Down"
    return dmc.Card(
        withBorder=True, shadow="md", radius="md", w=250, p="sm",
        children=[
            dmc.Group([
                dmc.Text(kpi["label"], fw=600),
                dmc.Badge(badge_text, color=color)
            ], justify="space-between"),
            dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)

        ]
    )

def image_card(kpi):
    return dmc.Card(
        withBorder=True, shadow="sm", radius="md", w=300,
        children=[
            dmc.CardSection(dmc.Image(src="https://raw.githubusercontent.com/mantinedev/mantine/master/.demo/images/bg-8.png", h=120, alt="BG")),
            dmc.Text(kpi["label"], fw=600, mt="sm"),
            dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)

        ]
    )

def paper_card(kpi):
    return dmc.Paper(shadow="sm", radius="md", p="md", withBorder=True, style={"background":"linear-gradient(45deg, #f3ec78, #af4261)"},
                     children=[
                         dmc.Text(kpi["label"], fw=600, c="white"),
                         dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)

                     ])

def sparkline_line_card(kpi):
    df = generate_sparkline_data()
    fig = px.line(df, x="x", y="y", height=60)
    fig.update_layout(margin=dict(l=0,r=0,t=0,b=0), xaxis=dict(visible=False), yaxis=dict(visible=False))
    return dmc.Card(
        withBorder=True, shadow="sm", radius="md", w=250, p="sm",
        children=[
            dmc.Text(kpi["label"], fw=600),
            dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)
,
            dmc.Graph(figure=fig, style={"height": "60px"})
        ]
    )

def sparkline_bar_card(kpi):
    df = generate_sparkline_data()
    fig = px.bar(df, x="x", y="y", height=60)
    fig.update_layout(margin=dict(l=0,r=0,t=0,b=0), xaxis=dict(visible=False), yaxis=dict(visible=False))
    return dmc.Card(
        withBorder=True, shadow="sm", radius="md", w=250, p="sm",
        children=[
            dmc.Text(kpi["label"], fw=600),
            dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)
,
            dmc.Graph(figure=fig, style={"height": "60px"})
        ]
    )

def highlight_card(kpi):
    return dmc.Card(
        withBorder=True, shadow="sm", radius="md", w=250, style={"borderLeft":"5px solid #ff6b6b"}, p="sm",
        children=[
            dmc.Text(kpi["label"], fw=700),
            dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)

        ]
    )

def segment_card(kpi):
    return dmc.Card(
        withBorder=True, shadow="sm", radius="md", w=250, p="sm",
        children=[
            dmc.Group([
                dmc.Text(kpi["label"], fw=600),
                dmc.Text(
    dmc.NumberFormatter(prefix="$ ", value=kpi["value"], thousandSeparator=True),
    style={"marginTop": "8px", "fontWeight": "bold", "fontSize": "1.2rem"}
)

            ], justify="space-between")
        ]
    )

def formatted_card(kpi):
    return dmc.Card(
        withBorder=True, shadow="sm", radius="md", w=250, p="sm",
        children=[
            dmc.Text(kpi["label"], fw=600),
            dmc.NumberFormatter(prefix="$ " if not kpi.get("is_percent") else "", value=kpi["value"], thousandSeparator=True)
        ]
    )

def mixed_card(kpi):
    df = generate_sparkline_data()
    fig = px.line(df, x="x", y="y", height=50)
    fig.update_layout(margin=dict(l=0,r=0,t=0,b=0), xaxis=dict(visible=False), yaxis=dict(visible=False))
    color = "green" if np.random.rand() > 0.5 else "red"
    badge_text = "Up" if color=="green" else "Down"
    return dmc.Card(
        withBorder=True, shadow="md", radius="md", w=250, p="sm",
        children=[
            dmc.Group([
                dmc.Text(kpi["label"], fw=600),
                dmc.Badge(badge_text, color=color)
            ], justify="space-between"),
            dmc.NumberFormatter(prefix="$ " if not kpi.get("is_percent") else "", value=kpi["value"], thousandSeparator=True),            
            dcc.Graph(figure=fig, style={"height": "50px"}, config={"displayModeBar": False})

        ]
    )

# App setup
app = dash.Dash(__name__)
app.layout = dmc.MantineProvider(
    theme={"colorScheme": "light"},
    children=dmc.Container(
        size="xl",
        px="md",
        children=[
            dmc.Title("Insurance KPI Dashboard", order=2, mb="md"),
            dmc.Tabs(
                [
                    dmc.TabsList([
                        dmc.TabsTab("Minimal", value="tab1"),
                        dmc.TabsTab("Badge", value="tab2"),
                        dmc.TabsTab("Image", value="tab3"),
                        dmc.TabsTab("Gradient", value="tab4"),
                        dmc.TabsTab("Sparkline Line", value="tab5"),
                        dmc.TabsTab("Sparkline Bar", value="tab6"),
                        dmc.TabsTab("Highlight", value="tab7"),
                        dmc.TabsTab("Segment", value="tab8"),
                        dmc.TabsTab("Formatted", value="tab9"),
                        dmc.TabsTab("Mixed", value="tab10"),
                    ]),
                    dmc.TabsPanel(id="tab1-panel", value="tab1", children=[
                        dmc.NumberInput(id="tab1-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab1-grid", cols=3, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab2-panel", value="tab2", children=[
                        dmc.NumberInput(id="tab2-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab2-grid", cols=3, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab3-panel", value="tab3", children=[
                        dmc.NumberInput(id="tab3-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab3-grid", cols=2, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab4-panel", value="tab4", children=[
                        dmc.NumberInput(id="tab4-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab4-grid", cols=2, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab5-panel", value="tab5", children=[
                        dmc.NumberInput(id="tab5-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab5-grid", cols=3, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab6-panel", value="tab6", children=[
                        dmc.NumberInput(id="tab6-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab6-grid", cols=3, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab7-panel", value="tab7", children=[
                        dmc.NumberInput(id="tab7-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab7-grid", cols=3, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab8-panel", value="tab8", children=[
                        dmc.NumberInput(id="tab8-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab8-grid", cols=3, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab9-panel", value="tab9", children=[
                        dmc.NumberInput(id="tab9-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab9-grid", cols=3, spacing="lg")
                    ]),
                    dmc.TabsPanel(id="tab10-panel", value="tab10", children=[
                        dmc.NumberInput(id="tab10-count", label="Number of KPIs", min=1, max=10, value=5, step=1, mb="md"),
                        dmc.SimpleGrid(id="tab10-grid", cols=3, spacing="lg")
                    ]),
                ],
                value="tab1",
                color="red",
                orientation="horizontal",
                variant="pills",
                id="tabs"
            )
        ]
    )
)

# Callbacks for each tab
@app.callback(Output("tab1-grid", "children"), Input("tab1-count", "value"))
def update_tab1(count): return [minimal_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab2-grid", "children"), Input("tab2-count", "value"))
def update_tab2(count): return [badge_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab3-grid", "children"), Input("tab3-count", "value"))
def update_tab3(count): return [image_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab4-grid", "children"), Input("tab4-count", "value"))
def update_tab4(count): return [paper_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab5-grid", "children"), Input("tab5-count", "value"))
def update_tab5(count): return [sparkline_line_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab6-grid", "children"), Input("tab6-count", "value"))
def update_tab6(count): return [sparkline_bar_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab7-grid", "children"), Input("tab7-count", "value"))
def update_tab7(count): return [highlight_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab8-grid", "children"), Input("tab8-count", "value"))
def update_tab8(count): return [segment_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab9-grid", "children"), Input("tab9-count", "value"))
def update_tab9(count): return [formatted_card(k) for k in kpi_data[:count]]

@app.callback(Output("tab10-grid", "children"), Input("tab10-count", "value"))
def update_tab10(count): return [mixed_card(k) for k in kpi_data[:count]]

if __name__ == "__main__":
    app.run(debug=True)
