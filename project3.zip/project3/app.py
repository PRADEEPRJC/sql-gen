import dash
from dash import dcc, Input, Output, State, no_update
import dash_mantine_components as dmc
from dash_iconify import DashIconify
import threading
import time
import os
import json
import uuid
from datetime import datetime

app = dash.Dash(__name__, suppress_callback_exceptions=True)

PROGRESS_STEPS = {
    'sql': {'label': 'SQL Query Generated', 'max_retries': 3, 'file': 'sql_completed.txt', 'folder': 'sql'},
    'data': {'label': 'SQL Executed', 'max_retries': 3, 'file': 'data_completed.txt', 'folder': 'data'}, 
    'dashboard': {'label': 'Dashboard Created', 'max_retries': 5, 'file': 'dashboard_completed.txt', 'folder': 'dashboard'}
}

OUTPUT_FOLDER = 'output'
PROGRESS_FILE = 'progress_status.json'

def create_session_folder(session_uuid):
    """Create session folder structure"""
    session_path = os.path.join(OUTPUT_FOLDER, session_uuid)
    os.makedirs(session_path, exist_ok=True)
    
    # Create subfolders for each step
    for step_config in PROGRESS_STEPS.values():
        folder_path = os.path.join(session_path, step_config['folder'])
        os.makedirs(folder_path, exist_ok=True)
    
    return session_path

def check_step_completion(session_uuid, step_name):
    """Check if a step is completed by looking for completion file"""
    step_config = PROGRESS_STEPS[step_name]
    completion_file_path = os.path.join(
        OUTPUT_FOLDER, 
        session_uuid, 
        step_config['folder'], 
        step_config['file']
    )
    return os.path.exists(completion_file_path)

def get_progress_status():
    """Get current progress status from file"""
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {
        'active_step': None,
        'steps': {},
        'in_progress': False,
        'start_time': None,
        'user_input': None,
        'session_uuid': None,
        'stepper_visible': False
    }

def save_progress_status(status):
    """Save progress status to file"""
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(status, f, indent=2)

def update_step_status(step_name, status, retry_count=0, error_message=None, session_uuid=None):
    """
    Update the status of a specific step from external code files.
    
    Args:
        step_name: 'sql', 'data', or 'dashboard'
        status: 'in_progress', 'completed', 'failed'
        retry_count: Current retry attempt (0 for first attempt)
        error_message: Optional error message for failed steps
        session_uuid: Session UUID for this process
    
    Usage examples from other files:
        update_step_status('sql', 'completed', session_uuid='your-uuid')
        update_step_status('data', 'failed', retry_count=1, error_message='Connection timeout', session_uuid='your-uuid')
        update_step_status('dashboard', 'in_progress', session_uuid='your-uuid')
    """
    current_status = get_progress_status()
    
    if step_name not in current_status['steps']:
        current_status['steps'][step_name] = {}
    
    current_status['steps'][step_name].update({
        'status': status,
        'retry_count': retry_count,
        'last_updated': datetime.now().isoformat(),
        'error_message': error_message
    })
    
    # Update active step
    if status == 'in_progress':
        current_status['active_step'] = step_name
    elif status in ['completed', 'failed']:
        # Move to next step if current step completed
        step_order = list(PROGRESS_STEPS.keys())
        current_index = step_order.index(step_name)
        
        if status == 'completed' and current_index < len(step_order) - 1:
            current_status['active_step'] = step_order[current_index + 1]
        elif current_index == len(step_order) - 1:
            current_status['active_step'] = None
            current_status['in_progress'] = False
    
    save_progress_status(current_status)
    return current_status

def should_retry(step_name, retry_count):
    """Check if step should be retried based on max retries"""
    max_retries = PROGRESS_STEPS[step_name]['max_retries']
    return retry_count < max_retries

def background_process(user_input, session_uuid):
    """Simulate background process with error handling and retries"""
    status = {
        'active_step': 'sql',
        'steps': {},
        'in_progress': True,
        'start_time': datetime.now().isoformat(),
        'user_input': user_input,
        'session_uuid': session_uuid,
        'stepper_visible': True
    }
    save_progress_status(status)
    
    step_order = list(PROGRESS_STEPS.keys())
    
    for step_name in step_order:
        retry_count = 0
        max_retries = PROGRESS_STEPS[step_name]['max_retries']
        
        while retry_count <= max_retries:
            # Update status to in_progress
            update_step_status(step_name, 'in_progress', retry_count, session_uuid=session_uuid)
            
            # Check if step is already completed (file exists)
            if check_step_completion(session_uuid, step_name):
                update_step_status(step_name, 'completed', retry_count, session_uuid=session_uuid)
                break
            
            # Simulate processing time - in real implementation, this would be your actual processing
            time.sleep(8)
            
            # Check again after processing (in case external process completed it)
            if check_step_completion(session_uuid, step_name):
                update_step_status(step_name, 'completed', retry_count, session_uuid=session_uuid)
                break
            
            # Simulate success/failure for demo (remove this in real implementation)
            import random
            success_rate = 0.7 if retry_count == 0 else 0.8  # Higher success on retries
            
            if random.random() < success_rate:
                # Success - create completion file for demo
                step_config = PROGRESS_STEPS[step_name]
                completion_file_path = os.path.join(
                    OUTPUT_FOLDER, 
                    session_uuid, 
                    step_config['folder'], 
                    step_config['file']
                )
                with open(completion_file_path, 'w') as f:
                    f.write(f"Step {step_name} completed at {datetime.now().isoformat()}")
                
                update_step_status(step_name, 'completed', retry_count, session_uuid=session_uuid)
                break
            else:
                # Failure
                retry_count += 1
                error_msg = f"Step failed - attempt {retry_count}"
                
                if retry_count <= max_retries:
                    update_step_status(step_name, 'failed', retry_count, error_msg, session_uuid=session_uuid)
                    time.sleep(2)  # Wait before retry
                else:
                    # Max retries exceeded
                    update_step_status(step_name, 'failed', retry_count, 
                                     f"Max retries ({max_retries}) exceeded", session_uuid=session_uuid)
                    # Stop the entire process
                    final_status = get_progress_status()
                    final_status['in_progress'] = False
                    final_status['active_step'] = None
                    save_progress_status(final_status)
                    return
    
    # All steps completed successfully
    final_status = get_progress_status()
    final_status['in_progress'] = False
    final_status['active_step'] = None
    save_progress_status(final_status)

def get_icon(icon, size=20):
    return DashIconify(icon=icon, height=size)

def create_stepper_steps():
    """Create stepper steps based on current progress"""
    status = get_progress_status()
    steps = []
    
    step_order = list(PROGRESS_STEPS.keys())
    session_uuid = status.get('session_uuid')
    
    for i, step_name in enumerate(step_order):
        step_config = PROGRESS_STEPS[step_name]
        step_status = status['steps'].get(step_name, {})
        
        current_status = step_status.get('status', 'waiting')
        retry_count = step_status.get('retry_count', 0)
        error_message = step_status.get('error_message', '')
        
        # Check if step is completed by file existence
        if session_uuid and check_step_completion(session_uuid, step_name):
            current_status = 'completed'
        
        # Determine step appearance
        is_active = status['active_step'] == step_name
        is_completed = current_status == 'completed'
        is_failed = current_status == 'failed'
        is_loading = current_status == 'in_progress'
        
        # Create description based on status
        if is_completed:
            if retry_count > 0:
                desc_text = f"✅ Completed after {retry_count} retries"
                desc_color = "green"
            else:
                desc_text = "✅ Completed successfully"
                desc_color = "green"
            description = dmc.Text(desc_text, size="sm", c=desc_color)
            
        elif is_failed:
            max_retries = step_config['max_retries']
            if retry_count >= max_retries:
                desc_text = f"❌ Failed after {retry_count} attempts"
                desc_color = "red"
            else:
                desc_text = f"🔄 Retrying... (Attempt {retry_count + 1}/{max_retries + 1})"
                desc_color = "orange"
            description = dmc.Text(desc_text, size="sm", c=desc_color)
            
        elif is_loading:
            if retry_count > 0:
                desc_text = f"⏳ In progress... (Retry {retry_count})"
            else:
                desc_text = "⏳ In progress..."
            description = dmc.Text(desc_text, size="sm", c="blue")
            
        else:
            description = dmc.Text("⏸️ Waiting...", c="dimmed", size="sm")
        
        # Create step content
        if is_completed:
            completion_path = f"output/{session_uuid}/{step_config['folder']}/{step_config['file']}"
            content = dmc.Alert([
                dmc.Text("Step completed successfully!", size="sm"), 
                dmc.Text(f"Completion file: {completion_path}", size="xs", c="dimmed", mt=5)
            ], color="green", variant="light")
        elif is_failed:
            max_retries = step_config['max_retries']
            if retry_count >= max_retries:
                content = dmc.Alert([
                    dmc.Text("Step failed permanently", size="sm", fw=500),
                    dmc.Text(error_message, size="xs", c="red") if error_message else None
                ], color="red", variant="light")
            else:
                content = dmc.Alert([
                    dmc.Text(f"Step failed, retrying... ({retry_count}/{max_retries})", size="sm"),
                    dmc.Text(error_message, size="xs") if error_message else None
                ], color="orange", variant="light")
        elif is_loading:
            expected_path = f"output/{session_uuid}/{step_config['folder']}/{step_config['file']}"
            content = dmc.Alert([
                dmc.Text("Step in progress...", size="sm"),
                dmc.Text(f"Waiting for: {expected_path}", size="xs", c="dimmed", mt=5)
            ], color="blue", variant="light")
        else:
            expected_path = f"output/{session_uuid}/{step_config['folder']}/{step_config['file']}"
            content = dmc.Alert([
                dmc.Text("Waiting to start...", c="dimmed", size="sm"),
                dmc.Text(f"Will create: {expected_path}", size="xs", c="dimmed", mt=5)
            ], color="gray", variant="light")
        
        # Choose appropriate icons
        if is_completed:
            icon = get_icon("material-symbols:check-circle")
        elif is_failed and retry_count >= step_config['max_retries']:
            icon = get_icon("material-symbols:error")
        elif is_failed:
            icon = get_icon("material-symbols:refresh")
        elif is_loading:
            icon = get_icon("material-symbols:hourglass-empty")
        else:
            icon = get_icon("material-symbols:radio-button-unchecked")
        
        step = dmc.StepperStep(
            label=step_config["label"],
            description=description,
            icon=icon,
            loading=is_loading,
            children=[content]
        )
        steps.append(step)
    
    # Add completion step if all steps are done
    all_completed = all(
        session_uuid and check_step_completion(session_uuid, step) 
        for step in step_order
    )
    
    if all_completed:
        steps.append(
            dmc.StepperCompleted(
                children=[
                    dmc.Alert(
                        [
                            dmc.Text("🎉 All steps completed successfully!", size="lg", fw=500),
                            dmc.Text(f"Session: {session_uuid}", size="sm", c="dimmed", mt=5),
                            dmc.Anchor("Go to Dashboard", href="/chart", fw=600, c="blue", mt=10)
                        ],
                        color="green",
                        variant="filled"
                    )
                ]
            )
        )
    elif not status['in_progress'] and status['steps']:
        # Process stopped due to failure
        steps.append(
            dmc.StepperCompleted(
                children=[
                    dmc.Alert(
                        [
                            dmc.Text("❌ Process stopped due to failures", size="lg", fw=500),
                            dmc.Text(f"Session: {session_uuid}", size="sm", c="dimmed", mt=5),
                            dmc.Text("Check the error messages above and try again", size="sm", mt=5)
                        ],
                        color="red",
                        variant="filled"
                    )
                ]
            )
        )
    
    return steps

app.layout = dmc.MantineProvider([
    dcc.Location(id='url', refresh=False),
    dcc.Interval(id='progress-interval', interval=2000, n_intervals=0),
    dmc.Stack(id='page-content')
])

def create_main_page():
    return dmc.Container([
        dmc.Title("Background Process Stepper with File-based Progress", order=2, mb=20),
        dmc.Paper([
            dmc.Textarea(
                id='user-input-visible',
                label="Enter your query or description:",
                placeholder="Describe what you want to analyze...",
                minRows=3,
                mb=20
            ),
            dmc.Group([
                dmc.Button("Submit", id="submit-btn-visible", color="blue", 
                          leftSection=get_icon("material-symbols:play-arrow")),
                dmc.Button("Go to Dashboard", id="dashboard-btn-visible", color="gray", 
                          variant="outline", leftSection=get_icon("material-symbols:dashboard")),
                dmc.Button("Clear Progress", id="clear-btn-visible", color="red", 
                          variant="outline", leftSection=get_icon("material-symbols:refresh"))
            ], mb=20),
            dmc.Stack(id="stepper-container-visible")
        ], p=20, shadow="sm")
    ], size="lg", mt=20)

def create_dashboard_page():
    return dmc.Container([
        dmc.Title("Dashboard Report Page", order=2, mb=20),
        dmc.Paper([
            dmc.Group([
                get_icon("material-symbols:dashboard", 40),
                dmc.Stack([
                    dmc.Text("Dashboard Report", size="xl", fw=500),
                    dmc.Text("This is a sample dashboard page.", size="md", c="dimmed")
                ])
            ], mb=20),
            dmc.Alert([
                dmc.Text("📊 The background process continues running while you're here.", size="sm"),
                dmc.Text("Return to the main page to check progress status.", size="sm", mt=5)
            ], color="blue", variant="light", mb=20),
            dmc.Button("Back to Progress", id="back-btn-visible", color="blue", 
                      leftSection=get_icon("material-symbols:arrow-back"))
        ], p=20, shadow="sm")
    ], size="lg", mt=20)

@app.callback(Output('page-content', 'children'), Input('url', 'pathname'))
def display_page(pathname):
    if pathname == '/dashboard':
        return create_dashboard_page()
    elif pathname == '/sql':
        return dmc.Container([dmc.Title("SQL Query Page", order=2), dmc.Text("SQL file generated.")], size="lg", mt=20)
    elif pathname == '/data':
        return dmc.Container([dmc.Title("Data Page", order=2), dmc.Text("Data file generated.")], size="lg", mt=20)
    elif pathname == '/chart':
        return create_dashboard_page()
    else:
        return create_main_page()

@app.callback(Output('url', 'pathname'), Input('dashboard-btn-visible', 'n_clicks'), prevent_initial_call=True)
def navigate_to_dashboard(n_clicks):
    if n_clicks:
        return '/dashboard'
    return no_update

@app.callback(Output('url', 'pathname', allow_duplicate=True), Input('back-btn-visible', 'n_clicks'), prevent_initial_call=True)
def navigate_to_home(n_clicks):
    if n_clicks:
        return '/'
    return no_update

@app.callback([Output('submit-btn-visible', 'disabled'), Output('clear-btn-visible', 'disabled')], 
              Input('submit-btn-visible', 'n_clicks'), State('user-input-visible', 'value'), 
              prevent_initial_call=True)
def start_background_process(n_clicks, user_input):
    if n_clicks and user_input:
        # Create new UUID for this session
        session_uuid = str(uuid.uuid4())
        
        # Create session folder structure
        create_session_folder(session_uuid)
        
        # Start background process
        thread = threading.Thread(target=background_process, args=(user_input, session_uuid))
        thread.daemon = True
        thread.start()
        return True, True
    return no_update, no_update

@app.callback([Output('user-input-visible', 'value'), 
               Output('submit-btn-visible', 'disabled', allow_duplicate=True), 
               Output('clear-btn-visible', 'disabled', allow_duplicate=True)], 
              Input('clear-btn-visible', 'n_clicks'), prevent_initial_call=True)
def clear_progress(n_clicks):
    if n_clicks:
        if os.path.exists(PROGRESS_FILE):
            os.remove(PROGRESS_FILE)
        return "", False, False
    return no_update, no_update, no_update

@app.callback(Output('stepper-container-visible', 'children'), 
              [Input('progress-interval', 'n_intervals'), Input('url', 'pathname')])
def update_stepper(n_intervals, pathname):
    if pathname != '/' and pathname is not None:
        return no_update

    status = get_progress_status()
    
    # Don't show stepper until user submits
    if not status.get('stepper_visible', False):
        return dmc.Alert(
            dmc.Group([
                get_icon("material-symbols:info", 24),
                dmc.Stack([
                    dmc.Text("Ready to start", size="lg", fw=500),
                    dmc.Text("Click Submit to begin the process and create a new session", size="sm")
                ], gap="xs")
            ]),
            color="blue", variant="light", mt=30
        )

    stepper_steps = create_stepper_steps()
    
    # Determine active step number for stepper
    step_order = list(PROGRESS_STEPS.keys())
    session_uuid = status.get('session_uuid')
    
    if status['active_step'] in step_order:
        active_step_num = step_order.index(status['active_step'])
    else:
        # Count completed steps based on file existence
        completed_count = 0
        if session_uuid:
            completed_count = sum(1 for step in step_order 
                                if check_step_completion(session_uuid, step))
        active_step_num = completed_count

    status_elements = []
    
    # Add session info
    if session_uuid:
        status_elements.append(
            dmc.Alert([
                get_icon("material-symbols:folder", 20),
                dmc.Text(f"Session: {session_uuid}", ml=10, size="sm", fw=500)
            ], color="gray", variant="light", mt=10)
        )
    
    if status['in_progress']:
        current_step = status['active_step']
        if current_step:
            current_step_info = status['steps'].get(current_step, {})
            retry_count = current_step_info.get('retry_count', 0)
            if retry_count > 0:
                status_text = f"Retrying {current_step} step (attempt {retry_count + 1})..."
            else:
                status_text = f"Processing {current_step} step..."
        else:
            status_text = "Process is running in background..."
            
        status_elements.append(
            dmc.Alert([
                get_icon("material-symbols:hourglass-empty", 20),
                dmc.Text(status_text, ml=10)
            ], color="blue", variant="light", mt=20)
        )
    elif status['steps']:
        step_order = list(PROGRESS_STEPS.keys())
        completed_steps = []
        failed_steps = []
        
        if session_uuid:
            completed_steps = [step for step in step_order 
                              if check_step_completion(session_uuid, step)]
            failed_steps = [step for step in step_order 
                           if status['steps'].get(step, {}).get('status') == 'failed']
        
        if len(completed_steps) == len(step_order):
            status_elements.append(
                dmc.Alert([
                    get_icon("material-symbols:check-circle", 20),
                    dmc.Text("All steps completed successfully!", ml=10)
                ], color="green", variant="light", mt=20)
            )
        elif failed_steps:
            status_elements.append(
                dmc.Alert([
                    get_icon("material-symbols:error", 20),
                    dmc.Text("Process stopped due to failures. Check steps above.", ml=10)
                ], color="red", variant="light", mt=20)
            )

    if status.get('start_time'):
        status_elements.append(
            dmc.Text(f"Started at: {status['start_time'][:19].replace('T', ' ')}", 
                    c="dimmed", size="xs", mt=10)
        )

    return dmc.Stack([
        dmc.Stepper(active=active_step_num, orientation="vertical", size="lg", 
                   children=stepper_steps),
        dmc.Stack(status_elements)
    ])

@app.callback([Output('submit-btn-visible', 'disabled', allow_duplicate=True), 
               Output('clear-btn-visible', 'disabled', allow_duplicate=True)], 
              Input('progress-interval', 'n_intervals'), prevent_initial_call=True)
def update_button_states(n_intervals):
    status = get_progress_status()
    return status['in_progress'], status['in_progress']

if __name__ == '__main__':
    # Create output directory if it doesn't exist
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    app.run(debug=True, port=8050)