import dash_mantine_components as dmc

def sql_page():
    return dmc.Container([
        dmc.Title("SQL Query Page", order=2),
        dmc.Text("Here you can view the generated SQL query."),
        dmc.CodeHighlight(code="SELECT * FROM policies;", language="sql")
    ], size="lg", mt=20)
