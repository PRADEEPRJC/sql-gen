"""
Optimized Metadata Filtering and SQL Generation System for P&C Insurance Analytics
"""

import spacy
from typing import List, Dict, Optional, Tuple, Set
import logging
from dataclasses import dataclass
from functools import lru_cache
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# -----------------------------
# Data Classes for Type Safety
# -----------------------------
@dataclass
class DirectField:
    source_table: str
    source_column: str
    alias_name: str
    data_type: Optional[str] = None
    description: Optional[str] = None

@dataclass
class DerivedField:
    source_table: str
    source_columns: str
    derived_name: str
    transformation_logic: str
    data_type: Optional[str] = None
    description: Optional[str] = None

@dataclass
class JoinCondition:
    from_table: str
    to_table: str
    join_condition: str
    join_type: str = "INNER"

@dataclass
class FilteredMetadata:
    direct_fields: List[DirectField]
    derived_fields: List[DerivedField]
    join_conditions: List[JoinCondition]
    relevance_scores: Dict[str, float]

# -----------------------------
# Enhanced Metadata Filtering Engine
# -----------------------------
class MetadataFilteringEngine:
    """
    Advanced metadata filtering engine with NLP-based relevance scoring
    """
    
    def __init__(self, model_name: str = "en_core_web_sm"):
        """Initialize the filtering engine with spaCy model"""
        try:
            self.nlp = spacy.load(model_name)
            logger.info(f"Loaded spaCy model: {model_name}")
        except OSError:
            logger.error(f"spaCy model '{model_name}' not found. Please install it using: python -m spacy download {model_name}")
            raise
        
        # P&C Insurance domain keywords for enhanced scoring
        self.domain_keywords = {
            'policy': ['policy', 'coverage', 'contract', 'agreement'],
            'claims': ['claim', 'loss', 'incident', 'damage', 'settlement'],
            'premium': ['premium', 'rate', 'price', 'cost', 'amount'],
            'time': ['year', 'month', 'quarter', 'date', 'period', 'time'],
            'metrics': ['count', 'sum', 'total', 'average', 'ratio', 'percentage'],
            'status': ['status', 'state', 'condition', 'active', 'inactive'],
            'geography': ['state', 'region', 'territory', 'location', 'zip']
        }
    
    @lru_cache(maxsize=128)
    def extract_keywords(self, query: str) -> Tuple[List[str], Dict[str, float]]:
        """
        Extract keywords with enhanced NLP processing and domain weighting
        
        Returns:
            Tuple of (keywords_list, keyword_weights)
        """
        doc = self.nlp(query.lower())
        keywords = {}
        
        # Extract tokens with POS filtering
        for token in doc:
            if (token.pos_ in {"NOUN", "PROPN", "VERB", "ADJ", "NUM"} and 
                not token.is_stop and 
                not token.is_punct and 
                len(token.text) > 2):
                
                lemma = token.lemma_
                
                # Base weight by POS tag
                if token.pos_ in {"NOUN", "PROPN"}:
                    weight = 3.0
                elif token.pos_ == "VERB":
                    weight = 2.0
                elif token.pos_ == "ADJ":
                    weight = 1.5
                else:
                    weight = 1.0
                
                # Domain-specific boosting
                for domain, domain_words in self.domain_keywords.items():
                    if lemma in domain_words:
                        weight *= 2.0
                        break
                
                keywords[lemma] = max(keywords.get(lemma, 0), weight)
        
        # Extract named entities
        for ent in doc.ents:
            if ent.label_ in {"ORG", "PRODUCT", "MONEY", "PERCENT", "DATE"}:
                keywords[ent.text.lower()] = 2.5
        
        return list(keywords.keys()), keywords
    
    def calculate_field_relevance(self, field_names: List[str], field_logic: str,
                                keywords: List[str], keyword_weights: Dict[str, float]) -> float:
        """
        Calculate relevance score for a field based on keyword matching
        """
        score = 0.0
        
        # Score field names (higher weight)
        for name in field_names:
            name_lower = name.lower()
            for keyword in keywords:
                # Exact match
                if keyword == name_lower:
                    score += keyword_weights[keyword] * 3.0
                # Partial match
                elif keyword in name_lower or name_lower in keyword:
                    score += keyword_weights[keyword] * 2.0
                # Fuzzy match using edit distance
                elif self._fuzzy_match(keyword, name_lower):
                    score += keyword_weights[keyword] * 1.0
        
        # Score transformation logic (lower weight)
        if field_logic:
            logic_lower = field_logic.lower()
            for keyword in keywords:
                if keyword in logic_lower:
                    score += keyword_weights[keyword] * 0.5
        
        return score
    
    def _fuzzy_match(self, word1: str, word2: str, threshold: float = 0.8) -> bool:
        """Simple fuzzy matching based on character overlap"""
        if len(word1) < 3 or len(word2) < 3:
            return False
        
        overlap = len(set(word1) & set(word2))
        min_len = min(len(word1), len(word2))
        return (overlap / min_len) >= threshold
    
    def filter_and_rank_metadata(self, 
                                query: str,
                                direct_fields: List[Dict],
                                derived_fields: List[Dict],
                                join_conditions: List[str],
                                relevance_threshold: float = 0.1,
                                top_n: Optional[int] = None) -> FilteredMetadata:
        """
        Enhanced metadata filtering with relevance scoring
        """
        logger.info(f"Processing query: {query}")
        
        keywords, keyword_weights = self.extract_keywords(query)
        logger.info(f"Extracted keywords: {keywords}")
        
        scored_direct = []
        scored_derived = []
        relevance_scores = {}
        
        # Process direct fields
        for field in direct_fields:
            field_names = [
                field.get("AliasName", ""),
                field.get("SourceColumn", ""),
                field.get("description", "")
            ]
            field_names = [name for name in field_names if name]  # Remove empty strings
            
            score = self.calculate_field_relevance(
                field_names, "", keywords, keyword_weights
            )
            
            if score >= relevance_threshold:
                direct_field = DirectField(
                    source_table=field.get("SourceTable", ""),
                    source_column=field.get("SourceColumn", ""),
                    alias_name=field.get("AliasName", ""),
                    data_type=field.get("DataType"),
                    description=field.get("Description")
                )
                scored_direct.append((score, direct_field))
                relevance_scores[f"direct_{field.get('SourceColumn', '')}"] = score
        
        # Process derived fields
        for field in derived_fields:
            field_names = [
                field.get("DerivedName", ""),
                field.get("description", "")
            ]
            field_names = [name for name in field_names if name]
            
            score = self.calculate_field_relevance(
                field_names,
                field.get("TransformationLogic", ""),
                keywords,
                keyword_weights
            )
            
            if score >= relevance_threshold:
                derived_field = DerivedField(
                    source_table=field.get("SourceTable", ""),
                    source_columns=field.get("SourceColumns", ""),
                    derived_name=field.get("DerivedName", ""),
                    transformation_logic=field.get("TransformationLogic", ""),
                    data_type=field.get("DataType"),
                    description=field.get("Description")
                )
                scored_derived.append((score, derived_field))
                relevance_scores[f"derived_{field.get('DerivedName', '')}"] = score
                
                # Auto-include source columns
                self._include_source_columns(
                    field, direct_fields, scored_direct, relevance_scores, score * 0.8
                )
        
        # Sort by relevance score (descending)
        scored_direct.sort(key=lambda x: x[0], reverse=True)
        scored_derived.sort(key=lambda x: x[0], reverse=True)
        
        # Apply top_n limit if specified
        if top_n:
            scored_direct = scored_direct[:top_n]
            scored_derived = scored_derived[:top_n]
        
        # Process join conditions
        processed_joins = self._process_join_conditions(join_conditions)
        
        logger.info(f"Filtered to {len(scored_direct)} direct fields and {len(scored_derived)} derived fields")
        
        return FilteredMetadata(
            direct_fields=[field for _, field in scored_direct],
            derived_fields=[field for _, field in scored_derived],
            join_conditions=processed_joins,
            relevance_scores=relevance_scores
        )
    
    def _include_source_columns(self, derived_field: Dict, direct_fields: List[Dict],
                               scored_direct: List[Tuple[float, DirectField]],
                               relevance_scores: Dict[str, float], score: float):
        """Include source columns for derived fields"""
        source_cols = [col.strip() for col in derived_field.get("SourceColumns", "").split(",")]
        
        for col in source_cols:
            for df in direct_fields:
                if (df.get("SourceColumn", "").lower() == col.lower() and
                    not any(df.get("SourceColumn") == field.source_column for _, field in scored_direct)):
                    
                    direct_field = DirectField(
                        source_table=df.get("SourceTable", ""),
                        source_column=df.get("SourceColumn", ""),
                        alias_name=df.get("AliasName", ""),
                        data_type=df.get("DataType"),
                        description=df.get("Description")
                    )
                    scored_direct.append((score, direct_field))
                    relevance_scores[f"direct_{col}"] = score
    
    def _process_join_conditions(self, join_conditions: List[str]) -> List[JoinCondition]:
        """Process join conditions into structured format"""
        processed_joins = []
        
        for condition in join_conditions:
            # Simple parsing - can be enhanced for complex conditions
            if "=" in condition:
                parts = condition.split("=")
                if len(parts) == 2:
                    left_table = parts[0].strip().split(".")[0]
                    right_table = parts[1].strip().split(".")[0]
                    
                    join_cond = JoinCondition(
                        from_table=left_table,
                        to_table=right_table,
                        join_condition=condition.strip(),
                        join_type="INNER"
                    )
                    processed_joins.append(join_cond)
        
        return processed_joins


# -----------------------------
# Updated SQL Generation Prompt
# -----------------------------
PC_INSURANCE_SQL_PROMPT_V2 = """
You are a Senior SQL Analytics Engineer specializing in Property & Casualty insurance data analysis. You have been provided with PRE-FILTERED, RELEVANCE-RANKED metadata that is most likely to answer the user's question.

## CORE MISSION
Generate production-ready Snowflake SQL queries using the provided filtered metadata. The metadata has already been processed and ranked by relevance to the user's question.

## METADATA UNDERSTANDING
The provided metadata contains:
- **DirectFields**: Pre-filtered columns ranked by relevance (highest scores first)
- **DerivedFields**: Pre-calculated measures ranked by relevance (highest scores first)  
- **JoinConditions**: Validated table relationships
- **RelevanceScores**: Confidence scores for each field's relevance

**IMPORTANT**: Only use fields from the provided filtered metadata. Do not assume or add any fields not listed.

## PROCESSING PROTOCOL

### STEP 1: ANALYZE FILTERED METADATA
- Review the pre-ranked direct fields (sorted by relevance)
- Examine the pre-scored derived fields (sorted by relevance)
- Note the available join relationships
- Understand the relevance scoring context

### STEP 2: CONSTRUCT OPTIMIZED QUERIES
- Prioritize highest-relevance fields from the filtered metadata
- Use derived fields when they directly match the analytical need
- Structure for visualization: clear dimensions + measures
- Apply P&C domain knowledge for business logic

### STEP 3: VALIDATE QUERY LOGIC
- Ensure all referenced fields exist in filtered metadata
- Verify join conditions are available
- Confirm query answers the business question
- Optimize for chart/dashboard consumption

## TECHNICAL REQUIREMENTS

### CONSTRAINTS
- Use ONLY fields from the filtered metadata provided
- Snowflake syntax exclusively
- SELECT statements only
- Extract filters as JSON parameters
- One query per analytical component

### SNOWFLAKE SYNTAX REFERENCE
```sql
-- Dates
DATE_TRUNC('MONTH', date_col)
DATEADD('DAY', 30, date_col)
DATEDIFF('DAYS', start_date, end_date)

-- Aggregations  
COUNT(DISTINCT field)
SUM(amount)
AVG(value)
LISTAGG(DISTINCT values, ', ')

-- Window Functions
ROW_NUMBER() OVER (PARTITION BY group ORDER BY sort)
LAG(field, 1) OVER (PARTITION BY id ORDER BY date)

-- Safe Operations
amount / NULLIF(denominator, 0)
COALESCE(field, 'Unknown')
IFF(condition, true_value, false_value)
```

## OUTPUT FORMATS

### SUCCESS RESPONSE
```json
[
  {{
    "title": "Descriptive analysis title",
    "sql": "SELECT dimensions, measures FROM tables WHERE conditions ORDER BY fields",
    "filters": ["param1", "param2"],
    "reasoning": "Explanation using filtered metadata relevance and business logic",
    "metadata_used": ["field1", "field2"],
    "relevance_confidence": "high|medium|low"
  }}
]
```

### ERROR RESPONSES
```json
// Insufficient Filtered Metadata
{{
  "error": "unanswerable",
  "reason": "insufficient_filtered_metadata",
  "available_fields": ["list_of_filtered_fields"],
  "suggestion": "The filtered metadata may not contain sufficient fields. Consider broadening the query or providing additional metadata."
}}

// Ambiguous Requirements
{{
  "error": "unanswerable", 
  "reason": "ambiguous_requirements",
  "clarification_needed": ["specific_aspect_unclear"],
  "suggestion": "Please clarify the specific metrics, dimensions, or time periods needed."
}}
```

## QUALITY GATES

### FIELD USAGE PRIORITY
1. **Derived Fields** (highest relevance): Use when they directly answer the question
2. **Direct Fields** (by relevance score): Select highest-scoring fields first
3. **Join Conditions**: Use provided relationships only
4. **Business Logic**: Apply P&C industry standards

### PROHIBITED ACTIONS
❌ Using fields not in filtered metadata
❌ Assuming additional columns exist
❌ Creating synthetic measures
❌ Ignoring relevance rankings
❌ Adding unauthorized joins

## INPUTS
**Business Question**: {user_question}
**Filtered Metadata**: {filtered_metadata}
**Relevance Scores**: {relevance_scores}

Generate the SQL query using the pre-filtered, relevance-ranked metadata provided.
"""

# -----------------------------
# Complete Integration System
# -----------------------------
class PnCAnalyticsSystem:
    """Complete P&C Insurance Analytics System"""
    
    def __init__(self):
        self.metadata_engine = MetadataFilteringEngine()
        self.sql_prompt_template = PC_INSURANCE_SQL_PROMPT_V2
    
    def process_query(self, user_question: str, direct_fields: List[Dict],
                     derived_fields: List[Dict], join_conditions: List[str],
                     relevance_threshold: float = 0.1, top_n: Optional[int] = 10) -> str:
        """
        Complete processing pipeline: metadata filtering -> SQL prompt generation
        """
        # Step 1: Filter and rank metadata
        filtered_metadata = self.metadata_engine.filter_and_rank_metadata(
            query=user_question,
            direct_fields=direct_fields,
            derived_fields=derived_fields,
            join_conditions=join_conditions,
            relevance_threshold=relevance_threshold,
            top_n=top_n
        )
        
        # Step 2: Format metadata for prompt
        metadata_dict = {
            "DirectFields": [
                {
                    "SourceTable": field.source_table,
                    "SourceColumn": field.source_column,
                    "AliasName": field.alias_name,
                    "DataType": field.data_type,
                    "Description": field.description
                }
                for field in filtered_metadata.direct_fields
            ],
            "DerivedFields": [
                {
                    "SourceTable": field.source_table,
                    "SourceColumns": field.source_columns,
                    "DerivedName": field.derived_name,
                    "TransformationLogic": field.transformation_logic,
                    "DataType": field.data_type,
                    "Description": field.description
                }
                for field in filtered_metadata.derived_fields
            ],
            "JoinConditions": [
                f"{join.from_table}.column = {join.to_table}.column"
                for join in filtered_metadata.join_conditions
            ]
        }
        
        # Step 3: Generate final prompt
        final_prompt = self.sql_prompt_template.format(
            user_question=user_question,
            filtered_metadata=str(metadata_dict),
            relevance_scores=str(filtered_metadata.relevance_scores)
        )
        
        return final_prompt


# -----------------------------
# Example Usage and Testing
# -----------------------------
if __name__ == "__main__":
    # Sample data (enhanced)
    direct_fields = [
        {"SourceTable": "policies", "SourceColumn": "policy_type", "AliasName": "policy type", "DataType": "VARCHAR"},
        {"SourceTable": "policies", "SourceColumn": "effective_year", "AliasName": "year", "DataType": "INTEGER"},
        {"SourceTable": "policies", "SourceColumn": "effective_month", "AliasName": "month", "DataType": "INTEGER"},
        {"SourceTable": "policies", "SourceColumn": "premium_amount", "AliasName": "premium", "DataType": "DECIMAL"},
        {"SourceTable": "claims", "SourceColumn": "claim_status", "AliasName": "status", "DataType": "VARCHAR"},
        {"SourceTable": "claims", "SourceColumn": "claim_amount", "AliasName": "claim amount", "DataType": "DECIMAL"}
    ]

    derived_fields = [
        {
            "SourceTable": "policies",
            "SourceColumns": "policy_type",
            "DerivedName": "new policy count",
            "TransformationLogic": "COUNT(CASE WHEN policy_type='new' THEN 1 END)",
            "DataType": "INTEGER"
        },
        {
            "SourceTable": "policies", 
            "SourceColumns": "policy_type",
            "DerivedName": "renewal policy count",
            "TransformationLogic": "COUNT(CASE WHEN policy_type='renewal' THEN 1 END)",
            "DataType": "INTEGER"
        },
        {
            "SourceTable": "policies",
            "SourceColumns": "premium_amount",
            "DerivedName": "total premium",
            "TransformationLogic": "SUM(premium_amount)",
            "DataType": "DECIMAL"
        }
    ]

    join_conditions = ["policies.policy_id = claims.policy_id"]

    # Initialize system
    analytics_system = PnCAnalyticsSystem()
    
    # Test query
    user_query = "What is the monthly trend of new policy count and total premium by policy type for the last year?"
    
    # Generate complete prompt
    final_prompt = analytics_system.process_query(
        user_question=user_query,
        direct_fields=direct_fields,
        derived_fields=derived_fields,
        join_conditions=join_conditions,
        top_n=5
    )
    
    print("="*50)
    print("COMPLETE PROCESSING PIPELINE RESULT")
    print("="*50)
    print(final_prompt)