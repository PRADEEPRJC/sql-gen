import os
import json
from datetime import datetime

PROGRESS_FILE = "progress_status.json"

def get_progress_status():
    """Get current progress status from file"""
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return {
        "steps": {},       # {"sql": {"status": "completed"}, ...}
        "active_step": -1,
        "in_progress": False,
        "start_time": None,
        "user_input": None
    }

def save_progress_status(status):
    """Save progress status to file"""
    with open(PROGRESS_FILE, "w") as f:
        json.dump(status, f, indent=2)

def update_step(step_name, status, retry=None):
    """Update a specific step (from anywhere in project)"""
    progress = get_progress_status()
    if "steps" not in progress:
        progress["steps"] = {}
    step_entry = {"status": status}
    if retry is not None:
        step_entry["retry"] = retry
    progress["steps"][step_name] = step_entry

    # Update active_step and in_progress flags
    progress["active_step"] = list(progress["steps"].keys()).index(step_name)
    progress["in_progress"] = status == "in_progress"

    # Add start_time if first run
    if not progress.get("start_time"):
        progress["start_time"] = datetime.now().isoformat()

    save_progress_status(progress)
