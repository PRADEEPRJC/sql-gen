# In your SQL processing script:
update_step_status('sql', 'completed', session_uuid='your-session-uuid')

# In your data processing script:  
update_step_status('data', 'failed', retry_count=1, error_message='Database connection failed', session_uuid='your-session-uuid')

# Example in your SQL script:
completion_file = f"output/{session_uuid}/sql/sql_completed.txt"
with open(completion_file, 'w') as f:
    f.write(f"SQL processing completed at {datetime.now().isoformat()}")