# progress_utils.py
"""
Utility functions for updating progress status from external code files.
Import this module in your other Python files to update progress status.
"""

import json
import os
from datetime import datetime

PROGRESS_FILE = 'progress_status.json'

PROGRESS_STEPS = {
    'sql': {'label': 'SQL Query Generated', 'max_retries': 3},
    'data': {'label': 'SQL Executed', 'max_retries': 3}, 
    'dashboard': {'label': 'Dashboard Created', 'max_retries': 5}
}

def get_progress_status():
    """Get current progress status from file"""
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error reading progress file: {e}")
            pass
    
    return {
        'active_step': None,
        'steps': {},
        'in_progress': False,
        'start_time': None,
        'user_input': None
    }

def save_progress_status(status):
    """Save progress status to file"""
    try:
        with open(PROGRESS_FILE, 'w') as f:
            json.dump(status, f, indent=2)
    except Exception as e:
        print(f"Error saving progress file: {e}")

def update_step_status(step_name, status, retry_count=0, error_message=None, details=None):
    """
    Update the status of a specific step.
    
    Args:
        step_name (str): Step name ('sql', 'data', or 'dashboard')
        status (str): Status ('in_progress', 'completed', 'failed')
        retry_count (int): Current retry attempt (0 for first attempt)
        error_message (str, optional): Error message for failed steps
        details (dict, optional): Additional details about the step
    
    Returns:
        dict: Updated progress status
        
    Examples:
        # Start a step
        update_step_status('sql', 'in_progress')
        
        # Complete a step
        update_step_status('sql', 'completed')
        
        # Fail a step with retry
        update_step_status('data', 'failed', retry_count=1, 
                          error_message='Database connection timeout')
        
        # Fail a step permanently (max retries exceeded)
        update_step_status('dashboard', 'failed', retry_count=5, 
                          error_message='Chart generation failed permanently')
    """
    if step_name not in PROGRESS_STEPS:
        raise ValueError(f"Invalid step name: {step_name}. Must be one of: {list(PROGRESS_STEPS.keys())}")
    
    if status not in ['in_progress', 'completed', 'failed']:
        raise ValueError(f"Invalid status: {status}. Must be one of: ['in_progress', 'completed', 'failed']")
    
    current_status = get_progress_status()
    
    # Initialize step if not exists
    if step_name not in current_status['steps']:
        current_status['steps'][step_name] = {}
    
    # Update step information
    step_info = {
        'status': status,
        'retry_count': retry_count,
        'last_updated': datetime.now().isoformat(),
        'error_message': error_message,
        'details': details or {}
    }
    
    current_status['steps'][step_name].update(step_info)
    
    # Update active step and process status
    step_order = list(PROGRESS_STEPS.keys())
    current_index = step_order.index(step_name)
    
    if status == 'in_progress':
        current_status['active_step'] = step_name
        current_status['in_progress'] = True
        
    elif status == 'completed':
        # Move to next step if current step completed
        if current_index < len(step_order) - 1:
            current_status['active_step'] = step_order[current_index + 1]
        else:
            # All steps completed
            current_status['active_step'] = None
            current_status['in_progress'] = False
            
    elif status == 'failed':
        max_retries = PROGRESS_STEPS[step_name]['max_retries']
        if retry_count >= max_retries:
            # Max retries exceeded, stop the process
            current_status['active_step'] = None
            current_status['in_progress'] = False
        # If retry_count < max_retries, keep the process running for retry
    
    save_progress_status(current_status)
    
    print(f"Progress updated: {step_name} -> {status}" + 
          (f" (retry {retry_count})" if retry_count > 0 else ""))
    
    return current_status

def start_process(user_input):
    """Initialize a new progress tracking process"""
    status = {
        'active_step': 'sql',  # Start with first step
        'steps': {},
        'in_progress': True,
        'start_time': datetime.now().isoformat(),
        'user_input': user_input
    }
    save_progress_status(status)
    print(f"Process started with input: {user_input}")
    return status

def get_step_info(step_name):
    """Get information about a specific step"""
    status = get_progress_status()
    return status['steps'].get(step_name, {})

def should_retry_step(step_name):
    """Check if a step should be retried based on current retry count"""
    step_info = get_step_info(step_name)
    retry_count = step_info.get('retry_count', 0)
    max_retries = PROGRESS_STEPS[step_name]['max_retries']
    return retry_count < max_retries

def get_retry_count(step_name):
    """Get current retry count for a step"""
    step_info = get_step_info(step_name)
    return step_info.get('retry_count', 0)

def is_process_running():
    """Check if any process is currently running"""
    status = get_progress_status()
    return status.get('in_progress', False)

def get_current_active_step():
    """Get the currently active step"""
    status = get_progress_status()
    return status.get('active_step')

def reset_progress():
    """Reset all progress (useful for testing or manual resets)"""
    if os.path.exists(PROGRESS_FILE):
        os.remove(PROGRESS_FILE)
    print("Progress reset successfully")

# Example usage and test functions
def test_progress_flow():
    """Test the complete progress flow"""
    print("Testing progress flow...")
    
    # Reset any existing progress
    reset_progress()
    
    # Start process
    start_process("Test query for progress tracking")
    
    # Simulate SQL step
    update_step_status('sql', 'in_progress')
    import time
    time.sleep(1)
    update_step_status('sql', 'completed')
    
    # Simulate data step with failure and retry
    update_step_status('data', 'in_progress')
    time.sleep(1)
    update_step_status('data', 'failed', retry_count=1, error_message='Connection timeout')
    
    # Retry data step
    update_step_status('data', 'in_progress', retry_count=1)
    time.sleep(1)
    update_step_status('data', 'completed', retry_count=1)
    
    # Simulate dashboard step
    update_step_status('dashboard', 'in_progress')
    time.sleep(1)
    update_step_status('dashboard', 'completed')
    
    print("Test completed! Check the progress_status.json file.")

if __name__ == "__main__":
    # Run test if this file is executed directly
    test_progress_flow()