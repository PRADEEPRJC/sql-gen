import spacy

# Load spaCy English model
nlp = spacy.load("en_core_web_sm")

# Sample metadata for illustration
direct_fields = [
    {"source_table": "table1", "source_column": "column1", "alias_name": "column 1"},
    {"source_table": "table1", "source_column": "year", "alias_name": "year"},
    {"source_table": "table1", "source_column": "month", "alias_name": "month"},
    {"source_table": "table1", "source_column": "policy_type", "alias_name": "policy_type"}
]

derived_fields = [
    {
        "alias_name": "policy_status",
        "source_table": "table1",
        "source_columns": ["column1", "column2", "column3"],
        "transformation_logic": "iff(column1==1,column2,column3)"
    }
]

def extract_keywords(query: str):
    """Extract nouns, proper nouns, adjectives, numbers, and entities as candidate keywords."""
    doc = nlp(query.lower())
    keywords = set()
    for token in doc:
        if token.pos_ in {"NOUN", "PROPN", "ADJ", "NUM"}:
            keywords.add(token.text)
    for ent in doc.ents:
        keywords.add(ent.text.lower())
    return keywords

def identify_relevant_metadata(keywords, direct_fields, derived_fields):
    """Return filtered direct and derived fields relevant to keywords."""
    relevant_direct = []
    relevant_derived = []
    
    direct_aliases = {df["alias_name"].lower(): df for df in direct_fields}
    direct_columns = {df["source_column"].lower(): df for df in direct_fields}
    
    # Match direct fields by alias or column
    for kw in keywords:
        if kw in direct_aliases and direct_aliases[kw] not in relevant_direct:
            relevant_direct.append(direct_aliases[kw])
        if kw in direct_columns and direct_columns[kw] not in relevant_direct:
            relevant_direct.append(direct_columns[kw])
    
    # Match derived fields by alias or involved source columns,
    # include their dependent direct fields as well
    for df in derived_fields:
        alias_lower = df["alias_name"].lower()
        source_cols_lower = [col.lower() for col in df["source_columns"]]
        if (alias_lower in keywords) or any(col in keywords for col in source_cols_lower):
            relevant_derived.append(df)
            for col in source_cols_lower:
                if col in direct_columns and direct_columns[col] not in relevant_direct:
                    relevant_direct.append(direct_columns[col])
    
    return relevant_direct, relevant_derived

# Example usage
query = "What is the policy count for new and renewal policies grouped by year and month?"
keywords = extract_keywords(query)
relevant_direct, relevant_derived = identify_relevant_metadata(keywords, direct_fields, derived_fields)

print("Extracted Keywords:", keywords)
print("\nRelevant Direct Fields:")
for field in relevant_direct:
    print(field)
print("\nRelevant Derived Fields:")
for field in relevant_derived:
    print(field)
