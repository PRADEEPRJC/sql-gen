prompt = """
You are an expert data visualization assistant specializing in Property & Casualty (P&C) insurance analytics. Your task is to analyze user questions about insurance data and generate appropriate chart parameters for dynamic visualization using Plotly.

**Available Chart Types:**
- line: Trend analysis (time series data)
- bar: Categorical comparisons
- scatter: Relationship analysis
- histogram: Distribution analysis  
- box: Performance variability
- area: Stacked trends
- pie: Portfolio composition
- choropleth: Geographic analysis (requires state_code column)

**Input Data:**
User Question: {user_question}
DataFrame Metadata: {dataframe_metadata}

**Your Task:**
Analyze the user's question and the available data to determine the most appropriate chart type and parameters. Generate a JSON response with the following structure:

{{
 "chart_type": "string (must be one of: 'line', 'bar', 'scatter', 'histogram', 'box', 'area', 'pie', 'choropleth')",
 "x_axis": "column_name or null",
 "y_axis": "column_name or null", 
 "color": "column_name or null (for grouping/coloring)",
 "size": "column_name or null (for bubble charts with scatter)",
 "facet_col": "column_name or null (for subplots)",
 "facet_row": "column_name or null (for subplots)",
 "aggregation": "string (e.g., 'sum', 'count', 'mean', 'max', 'min') or null",
 "title": "descriptive chart title",
 "x_title": "x-axis label",
 "y_title": "y-axis label",
 "filters": [
   {{
     "column": "column_name",
     "operator": "string (e.g., '>', '<', '==', 'in', 'contains')",
     "value": "filter_value"
   }}
 ],
 "sort_by": "column_name or null",
 "sort_order": "asc or desc",
 "limit": "integer or null (top N records)",
 "explanation": "brief explanation of why this visualization approach was chosen"
}}

**Chart Selection Guidelines:**
1. **line**: Use for time-based trends (requires date/time column)
2. **bar**: Use for comparing categories or groups
3. **scatter**: Use for analyzing relationships between two continuous variables
4. **histogram**: Use for showing distribution of a single continuous variable
5. **box**: Use for comparing distributions across categories or showing variability
6. **area**: Use for stacked trends over time or cumulative analysis
7. **pie**: Use for showing composition/proportions (limit to <8 categories)
8. **choropleth**: Use ONLY when geographic analysis is needed AND state_code column exists

**P&C Insurance Context:**
Consider common insurance metrics and relationships such as:
- Premium vs Claims analysis
- Loss ratios by coverage type, geography, or time
- Policy counts and distributions
- Claims frequency and severity
- Underwriting profitability metrics
- Risk factor analysis
- Geographic risk patterns
- Temporal trends in losses or premiums

**Important Rules:**
- Only use 'choropleth' if question involves geographic analysis AND 'state_code' column exists
- For time series questions, prioritize 'line' or 'area' charts
- For distribution questions, use 'histogram' or 'box'
- For composition/percentage questions, use 'pie' (max 8 categories)
- Use appropriate aggregations when raw data needs summarization
- Apply filters when the question implies data subsetting
- Generate only valid JSON response without additional explanation

Respond with valid JSON only.
"""

formatted_prompt = prompt.format(
    user_question="Show me the trend of total claims over time by coverage type",
    dataframe_metadata="Columns: policy_id (object), coverage_type (object), claim_date (datetime64), claim_amount (float64), state_code (object)"
)



import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json

def generate_chart(df, llm_response):
    """
    Generate Plotly chart from LLM response parameters
    
    Args:
        df (pd.DataFrame): The data to visualize
        llm_response (str or dict): JSON string or dict from LLM
    
    Returns:
        plotly.graph_objects.Figure: The generated chart
    """
    
    # Parse LLM response if it's a string
    if isinstance(llm_response, str):
        params = json.loads(llm_response)
    else:
        params = llm_response
    
    # Apply filters if specified
    filtered_df = df.copy()
    if params.get('filters'):
        for filter_item in params['filters']:
            col = filter_item['column']
            op = filter_item['operator']
            val = filter_item['value']
            
            if op == '==':
                filtered_df = filtered_df[filtered_df[col] == val]
            elif op == '>':
                filtered_df = filtered_df[filtered_df[col] > val]
            elif op == '<':
                filtered_df = filtered_df[filtered_df[col] < val]
            elif op == 'in':
                filtered_df = filtered_df[filtered_df[col].isin(val)]
            elif op == 'contains':
                filtered_df = filtered_df[filtered_df[col].str.contains(val, na=False)]
    
    # Apply aggregation if specified
    if params.get('aggregation') and params.get('x_axis'):
        agg_func = params['aggregation']
        group_cols = [col for col in [params.get('x_axis'), params.get('color')] if col]
        
        if agg_func == 'count':
            filtered_df = filtered_df.groupby(group_cols).size().reset_index(name=params.get('y_axis', 'count'))
        else:
            filtered_df = filtered_df.groupby(group_cols)[params.get('y_axis')].agg(agg_func).reset_index()
    
    # Apply sorting and limiting
    if params.get('sort_by'):
        ascending = params.get('sort_order', 'asc') == 'asc'
        filtered_df = filtered_df.sort_values(params['sort_by'], ascending=ascending)
    
    if params.get('limit'):
        filtered_df = filtered_df.head(params['limit'])
    
    # Generate chart based on type
    chart_type = params['chart_type']
    
    if chart_type == 'bar':
        fig = px.bar(filtered_df, 
                     x=params.get('x_axis'), 
                     y=params.get('y_axis'),
                     color=params.get('color'),
                     facet_col=params.get('facet_col'),
                     facet_row=params.get('facet_row'))
    
    elif chart_type == 'line':
        fig = px.line(filtered_df, 
                      x=params.get('x_axis'), 
                      y=params.get('y_axis'),
                      color=params.get('color'),
                      facet_col=params.get('facet_col'),
                      facet_row=params.get('facet_row'))
    
    elif chart_type == 'scatter':
        fig = px.scatter(filtered_df, 
                         x=params.get('x_axis'), 
                         y=params.get('y_axis'),
                         color=params.get('color'),
                         size=params.get('size'),
                         facet_col=params.get('facet_col'),
                         facet_row=params.get('facet_row'))
    
    elif chart_type == 'histogram':
        fig = px.histogram(filtered_df, 
                           x=params.get('x_axis'),
                           color=params.get('color'),
                           facet_col=params.get('facet_col'),
                           facet_row=params.get('facet_row'))
    
    elif chart_type == 'box':
        fig = px.box(filtered_df, 
                     x=params.get('x_axis'), 
                     y=params.get('y_axis'),
                     color=params.get('color'),
                     facet_col=params.get('facet_col'),
                     facet_row=params.get('facet_row'))
    
    elif chart_type == 'area':
        fig = px.area(filtered_df, 
                      x=params.get('x_axis'), 
                      y=params.get('y_axis'),
                      color=params.get('color'),
                      facet_col=params.get('facet_col'),
                      facet_row=params.get('facet_row'))
    
    elif chart_type == 'pie':
        fig = px.pie(filtered_df, 
                     values=params.get('y_axis'), 
                     names=params.get('x_axis'),
                     color=params.get('color'))
    
    elif chart_type == 'choropleth':
        fig = px.choropleth(filtered_df,
                            locations='state_code',
                            color=params.get('y_axis'),
                            locationmode='USA-states',
                            scope='usa')
    
    else:
        raise ValueError(f"Unsupported chart type: {chart_type}")
    
    # Update layout with titles
    fig.update_layout(
        title=params.get('title', ''),
        xaxis_title=params.get('x_title', ''),
        yaxis_title=params.get('y_title', '')
    )
    
    return fig

# Example usage:
if __name__ == "__main__":
    # Sample data
    sample_df = pd.DataFrame({
        'policy_id': ['P001', 'P002', 'P003', 'P004'],
        'coverage_type': ['Auto', 'Home', 'Auto', 'Home'],
        'claim_date': pd.to_datetime(['2024-01-01', '2024-01-15', '2024-02-01', '2024-02-15']),
        'claim_amount': [5000, 8000, 3000, 12000],
        'state_code': ['CA', 'TX', 'NY', 'FL']
    })
    
    # Sample LLM response
    llm_output = {
        "chart_type": "bar",
        "x_axis": "coverage_type",
        "y_axis": "claim_amount",
        "aggregation": "sum",
        "title": "Total Claims by Coverage Type",
        "x_title": "Coverage Type",
        "y_title": "Total Claim Amount"
    }
    
    # Generate chart
    chart = generate_chart(sample_df, llm_output)
    chart.show()


    