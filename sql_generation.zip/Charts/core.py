# Dynamic Chart Generation System for P&C Insurance

## 1. CHART GENERATION PROMPT TEMPLATE

"""
You are a P&C Insurance Data Visualization Expert. Generate chart configuration as JSON based on user questions and data metadata.

**Available Chart Types:**
- line: Trend analysis (time series data)
- bar: Categorical comparisons
- scatter: Relationship analysis
- histogram: Distribution analysis  
- box: Performance variability
- area: Stacked trends
- pie: Portfolio composition
- choropleth: Geographic analysis (requires state_code column)

**User Question:** {user_question}

**Data Metadata:**
{data_metadata}

**Instructions:**
1. Analyze the user question to determine the most appropriate chart type
2. Map data columns to chart parameters based on metadata
3. Generate appropriate title, labels, and formatting
4. Include filters and groupings if needed
5. Output ONLY valid JSON - no explanations


**JSON Schema:**
{
  "kpis": [
    {
      "title": "Written Premium",
      "value": "125000000",
      "format": "currency", 
      "trend": "+5.2%",
      "trend_direction": "up",
      "description": "Total premium written YTD"
    }
  ],
  "charts": [
    {
      "id": "chart_1",
      "chart_type": "line|bar|scatter|histogram|box|area|pie|choropleth",
      "data_config": {
        "x": "column_name",
        "y": "column_name", 
        "color": "column_name_optional"
      },
      "layout_config": {
        "title": "Chart Title",
        "height": 400,
        "width": "auto"
      },
      "filters": {
        "column_name": ["value1", "value2"]
      },
      "position": {
        "row": 1,
        "col": 1,
        "width": 6
      }
    }
  ],
  "global_filters": [
    {
      "column": "product_line",
      "type": "dropdown",
      "label": "Product Line",
      "default": "All"
    }
  ]
}

Generate the JSON configuration:
"""

## 2. PYTHON CHART GENERATOR FUNCTION

import json
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, dcc, html, Input, Output, callback
import dash_bootstrap_components as dbc

class PCInsuranceChartGenerator:
    def __init__(self):
        self.supported_charts = {
            'line': self._create_line_chart,
            'bar': self._create_bar_chart, 
            'scatter': self._create_scatter_chart,
            'histogram': self._create_histogram_chart,
            'box': self._create_box_chart,
            'area': self._create_area_chart,
            'pie': self._create_pie_chart,
            'choropleth': self._create_choropleth_chart
        }
    
    def generate_chart_from_json(self, df, chart_config_json):
        """
        Generate Plotly chart from JSON configuration
        
        Args:
            df: pandas DataFrame with insurance data
            chart_config_json: JSON string or dict with chart configuration
            
        Returns:
            plotly.graph_objects.Figure
        """
        try:
            # Parse JSON if string
            if isinstance(chart_config_json, str):
                config = json.loads(chart_config_json)
            else:
                config = chart_config_json
            
            # Apply filters if specified
            filtered_df = self._apply_filters(df, config.get('filters', {}))
            
            # Get chart type and generate
            chart_type = config['chart_type']
            if chart_type not in self.supported_charts:
                raise ValueError(f"Unsupported chart type: {chart_type}")
            
            # Create chart
            fig = self.supported_charts[chart_type](filtered_df, config)
            
            # Apply layout configuration
            self._apply_layout_config(fig, config.get('layout_config', {}))
            
            # Apply style configuration  
            self._apply_style_config(fig, config.get('style_config', {}))
            
            return fig
            
        except Exception as e:
            # Return error chart
            return self._create_error_chart(str(e))
    
    def _apply_filters(self, df, filters):
        """Apply filters to dataframe"""
        filtered_df = df.copy()
        for column, values in filters.items():
            if column in df.columns:
                filtered_df = filtered_df[filtered_df[column].isin(values)]
        return filtered_df
    
    def _create_line_chart(self, df, config):
        """Create line chart"""
        data_config = config['data_config']
        special_params = config.get('special_params', {})
        
        fig = px.line(
            df,
            x=data_config.get('x'),
            y=data_config.get('y'), 
            color=data_config.get('color'),
            facet_col=data_config.get('facet_col'),
            facet_row=data_config.get('facet_row')
        )
        return fig
    
    def _create_bar_chart(self, df, config):
        """Create bar chart"""
        data_config = config['data_config']
        special_params = config.get('special_params', {})
        
        fig = px.bar(
            df,
            x=data_config.get('x'),
            y=data_config.get('y'),
            color=data_config.get('color'),
            facet_col=data_config.get('facet_col'),
            facet_row=data_config.get('facet_row'),
            barmode=special_params.get('barmode', 'relative'),
            orientation=special_params.get('orientation')
        )
        return fig
    
    def _create_scatter_chart(self, df, config):
        """Create scatter plot"""
        data_config = config['data_config']
        special_params = config.get('special_params', {})
        
        fig = px.scatter(
            df,
            x=data_config.get('x'),
            y=data_config.get('y'),
            color=data_config.get('color'),
            size=data_config.get('size'),
            facet_col=data_config.get('facet_col'),
            facet_row=data_config.get('facet_row'),
            marginal_x=special_params.get('marginal'),
            marginal_y=special_params.get('marginal')
        )
        return fig
    
    def _create_histogram_chart(self, df, config):
        """Create histogram"""
        data_config = config['data_config']
        special_params = config.get('special_params', {})
        
        fig = px.histogram(
            df,
            x=data_config.get('x'),
            y=data_config.get('y'),
            color=data_config.get('color'),
            facet_col=data_config.get('facet_col'),
            facet_row=data_config.get('facet_row'),
            nbins=special_params.get('nbins', 20)
        )
        return fig
    
    def _create_box_chart(self, df, config):
        """Create box plot"""
        data_config = config['data_config']
        
        fig = px.box(
            df,
            x=data_config.get('x'),
            y=data_config.get('y'),
            color=data_config.get('color'),
            facet_col=data_config.get('facet_col'),
            facet_row=data_config.get('facet_row')
        )
        return fig
    
    def _create_area_chart(self, df, config):
        """Create area chart"""
        data_config = config['data_config']
        
        fig = px.area(
            df,
            x=data_config.get('x'),
            y=data_config.get('y'),
            color=data_config.get('color'),
            facet_col=data_config.get('facet_col'),
            facet_row=data_config.get('facet_row')
        )
        return fig
    
    def _create_pie_chart(self, df, config):
        """Create pie chart"""
        data_config = config['data_config']
        
        # Aggregate data for pie chart
        if data_config.get('color'):
            grouped_df = df.groupby(data_config['color'])[data_config['y']].sum().reset_index()
            fig = px.pie(
                grouped_df,
                values=data_config.get('y'),
                names=data_config.get('color')
            )
        else:
            fig = px.pie(
                df,
                values=data_config.get('y'),
                names=data_config.get('x')
            )
        return fig
    
    def _create_choropleth_chart(self, df, config):
        """Create choropleth map"""
        data_config = config['data_config']
        
        fig = px.choropleth(
            df,
            locations=data_config.get('x'),  # Should be state codes
            color=data_config.get('y'),
            locationmode='USA-states',
            scope='usa'
        )
        return fig
    
    def _apply_layout_config(self, fig, layout_config):
        """Apply layout configuration"""
        fig.update_layout(
            title=layout_config.get('title', ''),
            xaxis_title=layout_config.get('xaxis_title', ''),
            yaxis_title=layout_config.get('yaxis_title', ''),
            height=layout_config.get('height', 500),
            width=layout_config.get('width', 800)
        )
    
    def _apply_style_config(self, fig, style_config):
        """Apply style configuration"""
        if 'template' in style_config:
            fig.update_layout(template=style_config['template'])
        
        # Apply color configurations if available
        if hasattr(fig.data[0], 'marker') and 'color_discrete_sequence' in style_config:
            fig.update_traces(marker_color=style_config['color_discrete_sequence'][0])
    
    def _create_error_chart(self, error_message):
        """Create error display chart"""
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error generating chart: {error_message}",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False,
            font=dict(size=16, color="red")
        )
        fig.update_layout(
            title="Chart Generation Error",
            xaxis=dict(visible=False),
            yaxis=dict(visible=False)
        )
        return fig
    
    def generate_kpis(self, df, kpi_configs):
        """Generate KPI cards from configuration"""
        kpi_cards = []
        
        for kpi_config in kpi_configs:
            # Calculate KPI value from data
            value = self._calculate_kpi_value(df, kpi_config)
            
            kpi_card = dbc.Card([
                dbc.CardBody([
                    html.H6(kpi_config['title'], className="card-subtitle mb-2 text-muted"),
                    html.H3([
                        self._format_kpi_value(value, kpi_config.get('format', 'number')),
                        html.Small(
                            f" {kpi_config.get('trend', '')}", 
                            className=f"text-{self._get_trend_color(kpi_config.get('trend_direction', 'neutral'))}"
                        ) if kpi_config.get('trend') else ""
                    ], className="card-title"),
                    html.P(kpi_config.get('description', ''), className="card-text small")
                ])
            ], className="text-center h-100")
            
            kpi_cards.append(kpi_card)
        
        return kpi_cards
    
    def _calculate_kpi_value(self, df, kpi_config):
        """Calculate KPI value based on configuration"""
        # This would contain logic to calculate KPIs from data
        # For now, return the configured value
        return kpi_config.get('value', 0)
    
    def _format_kpi_value(self, value, format_type):
        """Format KPI values"""
        if format_type == 'currency':
            return f"${float(value):,.0f}"
        elif format_type == 'percentage':
            return f"{float(value):.1f}%"
        elif format_type == 'number':
            return f"{float(value):,.0f}"
        return str(value)
    
    def _get_trend_color(self, direction):
        """Get color class for trend"""
        return {
            'up': 'success',
            'down': 'danger', 
            'neutral': 'muted'
        }.get(direction, 'muted')
    
    def create_chart_grid(self, charts_config, df):
        """Create responsive grid of charts"""
        rows = []
        current_row = []
        current_width = 0
        
        for chart_config in charts_config:
            chart_width = chart_config.get('position', {}).get('width', 6)
            
            # If adding this chart exceeds row width, start new row
            if current_width + chart_width > 12:
                if current_row:
                    rows.append(dbc.Row(current_row, className="mb-4"))
                current_row = []
                current_width = 0
            
            # Generate chart
            fig = self.generate_chart_from_json(df, chart_config)
            
            # Create chart column
            chart_col = dbc.Col([
                dcc.Graph(
                    figure=fig,
                    id=chart_config.get('id', f'chart_{len(current_row)}')
                )
            ], width=chart_width)
            
            current_row.append(chart_col)
            current_width += chart_width
        
        # Add final row
        if current_row:
            rows.append(dbc.Row(current_row, className="mb-4"))
        
        return rows

## 3. DASH APPLICATION INTEGRATION

def create_dash_app(df, metadata):
    """Create Dash app with KPIs and dynamic chart generation"""
    
    app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
    chart_generator = PCInsuranceChartGenerator()
    
    app.layout = dbc.Container([
        # Header
        dbc.Row([
            dbc.Col([
                html.H2("P&C Insurance Dashboard", className="text-center mb-4"),
            ])
        ]),
        
        # User Input Section
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardBody([
                        html.H5("Ask a Question About Your Data"),
                        dbc.Textarea(
                            id="user-question",
                            placeholder="e.g., Show me premium performance and key metrics",
                            rows=2,
                            className="mb-3"
                        ),
                        dbc.Button(
                            "Generate Dashboard", 
                            id="generate-btn",
                            color="primary"
                        )
                    ])
                ], className="mb-4")
            ])
        ]),
        
        # Global Filters Section  
        dbc.Row([
            dbc.Col([
                html.Div(id="global-filters", className="mb-4")
            ])
        ]),
        
        # KPIs Section
        dbc.Row([
            dbc.Col([
                html.H4("Key Performance Indicators", className="mb-3"),
                html.Div(id="kpi-section")
            ])
        ], className="mb-4"),
        
        # Charts Section
        dbc.Row([
            dbc.Col([
                html.H4("Analytics", className="mb-3"),
                html.Div(id="charts-section")
            ])
        ]),
        
        # Hidden div to store config
        html.Div(id="dashboard-config", style={"display": "none"})
    ])
    
    return app

def generate_chart_config(user_question, metadata):
    """
    Generate chart configuration JSON based on user question and metadata.
    In production, this would call an LLM with the prompt template.
    For demo purposes, returns a sample configuration.
    """
    
    # Sample configuration - in production, this would be generated by LLM
    sample_config = {
        "chart_type": "line",
        "data_config": {
            "x": "month",
            "y": "written_premium", 
            "color": "product_line"
        },
        "layout_config": {
            "title": "Premium Trends by Product Line",
            "xaxis_title": "Month",
            "yaxis_title": "Written Premium ($)",
            "height": 500,
            "width": 800
        },
        "style_config": {
            "template": "plotly_white"
        },
        "filters": {},
        "special_params": {}
    }
    
    return sample_config

def generate_dashboard_config(user_question, metadata):
    """Generate complete dashboard configuration"""
    
    # Sample configuration - in production, this would be generated by LLM
    sample_config = {
        "kpis": [
            {
                "title": "Total Written Premium",
                "value": "125000000",
                "format": "currency",
                "trend": "+5.2%", 
                "trend_direction": "up",
                "description": "YTD written premium"
            },
            {
                "title": "Loss Ratio",
                "value": "0.68",
                "format": "percentage",
                "trend": "-2.1%",
                "trend_direction": "down", 
                "description": "Current loss ratio"
            },
            {
                "title": "Policy Count",
                "value": "45230",
                "format": "number",
                "trend": "+8.7%",
                "trend_direction": "up",
                "description": "Active policies"
            },
            {
                "title": "Combined Ratio", 
                "value": "0.96",
                "format": "percentage",
                "trend": "+1.2%",
                "trend_direction": "up",
                "description": "Overall profitability"
            }
        ],
        "charts": [
            {
                "id": "premium_trends",
                "chart_type": "line",
                "data_config": {
                    "x": "month",
                    "y": "written_premium",
                    "color": "product_line"
                },
                "layout_config": {
                    "title": "Premium Trends by Product Line",
                    "height": 400
                },
                "position": {"row": 1, "col": 1, "width": 6}
            },
            {
                "id": "loss_ratio_comparison",
                "chart_type": "bar", 
                "data_config": {
                    "x": "product_line",
                    "y": "loss_ratio",
                    "color": "product_line"
                },
                "layout_config": {
                    "title": "Loss Ratio by Product Line",
                    "height": 400
                },
                "position": {"row": 1, "col": 2, "width": 6}
            }
        ],
        "global_filters": [
            {
                "column": "product_line",
                "type": "dropdown",
                "label": "Product Line",
                "default": "All"
            }
        ]
    }
    
    return sample_config

@app.callback(
    [Output("kpi-section", "children"),
     Output("charts-section", "children"), 
     Output("global-filters", "children"),
     Output("dashboard-config", "children")],
    [Input("generate-btn", "n_clicks")],
    [State("user-question", "value")]
)
def generate_dashboard(n_clicks, user_question):
    if not n_clicks or not user_question:
        return [], [], [], ""
    
    # Generate dashboard configuration
    dashboard_config = generate_dashboard_config(user_question, metadata)
    
    # Generate KPIs
    kpi_cards = chart_generator.generate_kpis(df, dashboard_config.get('kpis', []))
    kpi_rows = create_kpi_rows(kpi_cards)
    
    # Generate Charts
    chart_rows = chart_generator.create_chart_grid(dashboard_config.get('charts', []), df)
    
    # Generate Global Filters
    global_filters = create_global_filters(dashboard_config.get('global_filters', []))
    
    return kpi_rows, chart_rows, global_filters, json.dumps(dashboard_config)

def create_kpi_rows(kpi_cards):
    """Arrange KPI cards in rows"""
    if not kpi_cards:
        return []
    
    # Determine optimal layout
    total_kpis = len(kpi_cards)
    
    if total_kpis <= 4:
        # Single row
        cols_per_kpi = 12 // total_kpis
        row = dbc.Row([
            dbc.Col(card, width=cols_per_kpi) for card in kpi_cards
        ], className="mb-4")
        return [row]
    else:
        # Multiple rows - 4 KPIs per row
        rows = []
        for i in range(0, total_kpis, 4):
            row_kpis = kpi_cards[i:i+4]
            cols_per_kpi = 12 // len(row_kpis)
            row = dbc.Row([
                dbc.Col(card, width=cols_per_kpi) for card in row_kpis
            ], className="mb-4")
            rows.append(row)
        return rows

def create_global_filters(filter_configs):
    """Create global filter components"""
    if not filter_configs:
        return []
    
    filters = []
    for filter_config in filter_configs:
        if filter_config['type'] == 'dropdown':
            filter_component = dbc.Col([
                html.Label(filter_config['label']),
                dcc.Dropdown(
                    id=f"filter-{filter_config['column']}",
                    options=[{'label': 'All', 'value': 'All'}],  # Would populate from data
                    value=filter_config.get('default', 'All')
                )
            ], width=3)
            filters.append(filter_component)
    
    return [dbc.Row(filters, className="mb-3")] if filters else []

## 4. EXAMPLE USAGE

if __name__ == "__main__":
    # Sample data
    sample_data = pd.DataFrame({
        'month': ['2023-01', '2023-02', '2023-03'] * 3,
        'written_premium': [1000000, 1100000, 1200000, 800000, 850000, 900000, 600000, 620000, 640000],
        'product_line': ['Auto', 'Auto', 'Auto', 'Property', 'Property', 'Property', 'Commercial', 'Commercial', 'Commercial'],
        'loss_ratio': [0.65, 0.68, 0.70, 0.55, 0.57, 0.59, 0.70, 0.72, 0.74],
        'state_code': ['CA', 'CA', 'CA', 'TX', 'TX', 'TX', 'FL', 'FL', 'FL']
    })
    
    # Sample metadata
    metadata = {
        'columns': {
            'month': {'type': 'datetime', 'description': 'Month of data'},
            'written_premium': {'type': 'numeric', 'description': 'Premium amount written'},
            'product_line': {'type': 'categorical', 'values': ['Auto', 'Property', 'Commercial']},
            'loss_ratio': {'type': 'numeric', 'description': 'Loss ratio percentage'},
            'state_code': {'type': 'categorical', 'description': 'US state codes'}
        }
    }
    
    # Initialize chart generator
    chart_generator = PCInsuranceChartGenerator()
    
    # Sample JSON configuration
    sample_json = {
        "chart_type": "line",
        "data_config": {
            "x": "month",
            "y": "written_premium",
            "color": "product_line"
        },
        "layout_config": {
            "title": "Premium Trends by Product Line",
            "xaxis_title": "Month", 
            "yaxis_title": "Written Premium ($)"
        },
        "style_config": {
            "template": "plotly_white"
        }
    }
    
    # Generate chart
    fig = chart_generator.generate_chart_from_json(sample_data, sample_json)
    fig.show()
    
    # Run Dash app
    # app = create_dash_app(sample_data, metadata)
    # app.run_server(debug=True)