prompt = """
You are a P&C Insurance Data Visualization Expert.  
Convert the **User Question** and **DataFrame Metadata** into a structured **Plotly chart configuration JSON**.  

**Available Chart Types:**  
- line → Trend analysis (time series)  
- bar → Categorical comparisons  
- scatter → Relationship analysis  
- histogram → Distribution analysis  
- box → Performance variability  
- area → Stacked trends  
- pie → Portfolio composition  
- choropleth → Geographic analysis (requires `state_code` column)  

**Inputs:**  
- User Question: {user_question}  
- DataFrame Metadata (columns & data types): {data_metadata}  

**Rules:**  
1. Select the best chart type from the list above.  
2. Map metadata fields to chart parameters (`x`, `y`, `color`, `size`, etc.).  
3. Generate meaningful titles, axis labels, and formatting.  
4. Add filters/groupings if implied by the question.  
5. Output **only valid JSON** (no explanations).  

**Output JSON Schema:**  
{
  "chart_type": "line|bar|scatter|histogram|box|area|pie|choropleth",
  "data_config": {
    "x": "column_name",
    "y": "column_name",
    "color": "optional_column",
    "size": "optional_column"
  },
  "layout_config": {
    "title": "Chart Title",
    "xaxis_title": "X Axis Label",
    "yaxis_title": "Y Axis Label",
    "height": 400,
    "width": "auto"
  },
  "filters": {
    "column_name": ["value1", "value2"]
  }
}
"""

import json
import dash
from dash import dcc, html
import dash_mantine_components as dmc
import plotly.express as px
import pandas as pd

# -----------------------------
# Sample Data (replace with your df)
# -----------------------------
df = pd.DataFrame({
    "state_code": ["CA", "TX", "NY", "FL", "IL"],
    "premium": [120000, 90000, 80000, 75000, 65000],
    "year": [2021, 2021, 2021, 2021, 2021],
    "product_line": ["Auto", "Home", "Cyber", "Auto", "Home"]
})

# -----------------------------
# Sample LLM JSON output (replace this with actual LLM response)
# -----------------------------
llm_output = """
{
  "chart_type": "bar",
  "data_config": {
    "x": "state_code",
    "y": "premium",
    "color": "product_line"
  },
  "layout_config": {
    "title": "Premium by State and Product Line",
    "xaxis_title": "State",
    "yaxis_title": "Premium ($)",
    "height": 400,
    "width": "auto"
  },
  "filters": {
    "year": [2021]
  }
}
"""

# Parse JSON
chart_config = json.loads(llm_output)

# -----------------------------
# Apply filters from JSON
# -----------------------------
filtered_df = df.copy()
for col, values in chart_config.get("filters", {}).items():
    filtered_df = filtered_df[filtered_df[col].isin(values)]

# -----------------------------
# Build Plotly figure dynamically
# -----------------------------
chart_type = chart_config["chart_type"]
data_cfg = chart_config["data_config"]
layout_cfg = chart_config["layout_config"]

if chart_type == "bar":
    fig = px.bar(filtered_df, x=data_cfg["x"], y=data_cfg["y"], color=data_cfg.get("color"))
elif chart_type == "line":
    fig = px.line(filtered_df, x=data_cfg["x"], y=data_cfg["y"], color=data_cfg.get("color"))
elif chart_type == "scatter":
    fig = px.scatter(filtered_df, x=data_cfg["x"], y=data_cfg["y"], color=data_cfg.get("color"), size=data_cfg.get("size"))
elif chart_type == "histogram":
    fig = px.histogram(filtered_df, x=data_cfg["x"], color=data_cfg.get("color"))
elif chart_type == "box":
    fig = px.box(filtered_df, x=data_cfg["x"], y=data_cfg["y"], color=data_cfg.get("color"))
elif chart_type == "area":
    fig = px.area(filtered_df, x=data_cfg["x"], y=data_cfg["y"], color=data_cfg.get("color"))
elif chart_type == "pie":
    fig = px.pie(filtered_df, names=data_cfg["x"], values=data_cfg["y"], color=data_cfg.get("color"))
elif chart_type == "choropleth":
    fig = px.choropleth(
        filtered_df,
        locations=data_cfg["x"],
        locationmode="USA-states",
        color=data_cfg["y"],
        scope="usa"
    )
else:
    raise ValueError(f"Unsupported chart type: {chart_type}")

# Update layout
fig.update_layout(
    title=layout_cfg["title"],
    xaxis_title=layout_cfg.get("xaxis_title"),
    yaxis_title=layout_cfg.get("yaxis_title"),
    height=layout_cfg.get("height", 400)
)

# -----------------------------
# Dash Mantine App
# -----------------------------
app = dash.Dash(__name__)

app.layout = dmc.MantineProvider(
    children=dmc.Container(
        [
            dmc.Title("Dynamic Chart Generator", order=2, align="center"),
            dmc.Space(h=20),
            dcc.Graph(figure=fig)
        ],
        fluid=True
    )
)

if __name__ == "__main__":
    app.run_server(debug=True)
